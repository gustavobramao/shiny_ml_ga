library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

get_daily_forecast <- function(){
    ####
    #### MC_uae
    ###
    print("Fetching Daily Forecast Data..")
    df_all <- read.csv("df_all.csv", stringsAsFactors = F, header = T)
    start_date <- Sys.Date() - 300
    end_date <- Sys.Date() - 1

    ga_id <- "ga:114955062"
    h_mc_uae1 <- google_analytics(ga_id,
                                  date_range = c(start_date, end_date),
                                  metrics = c("sessions", "transactions", "transactionsPerSession"),
                                  dimensions = "date")


    #rename col
    colnames(h_mc_uae1) <- c("ds", "sessions", "y", "cvr")


    ### transform date
    h_mc_uae1$ds <- as.Date(h_mc_uae1$ds)

    #import promo calendar.
    promo_mc_uae <- gsheet2tbl('https://docs.google.com/spreadsheets/d/1id5B62SMR-kieCRdoa20p7na9stBdldf7AB8yNGxE-Q/edit?usp=sharing')


    ### start modeling
    m <- prophet(h_mc_uae1, growth = "linear", changepoint.range = 0.9, daily.seasonality = TRUE, weekly.seasonality = TRUE,
                 holidays = promo_mc_uae, seasonality.mode = "multiplicative",
                 changepoint.prior.scale = 0.2)
    future <- make_future_dataframe(m, periods = 30)
    forecast_mc_uae1 <- predict(m, future)
    tail(forecast_mc_uae1[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_mc_uae1[nrow(h_mc_uae1) + 30,] <- NA
    forecast_mc_uae1$r_orders <- h_mc_uae1$y
    forecast_mc_uae1$brand_country <- "mc_uae"


    ####
    #### MC_KSA
    ###

    start_date <- Sys.Date() - 300
    end_date <- Sys.Date() - 1

    ga_id <- "ga:114976409"
    h_mc_ksa1 <- google_analytics(ga_id,
                                  date_range = c(start_date, end_date),
                                  metrics = c("sessions", "transactions", "transactionsPerSession"),
                                  dimensions = "date")


    #rename col
    colnames(h_mc_ksa1) <- c("ds", "sessions", "y", "cvr")


    ### transform date
    h_mc_ksa1$ds <- as.Date(h_mc_ksa1$ds)

    #import promo calendar.
    promo_mc_ksa <- gsheet2tbl('https://docs.google.com/spreadsheets/d/1NylNgZgIuXoliFh5Pg3Q4PO_fp8xZ8HZbKL3NhcnSP8/edit?usp=sharing')


    ### start modeling
    m <- prophet(h_mc_ksa1, growth = "linear", changepoint.range = 0.9, daily.seasonality = TRUE, weekly.seasonality = TRUE,
                 holidays = promo_mc_ksa, seasonality.mode = "multiplicative",
                 changepoint.prior.scale = 0.2)
    future <- make_future_dataframe(m, periods = 30)
    forecast_mc_ksa1 <- predict(m, future)
    tail(forecast_mc_ksa1[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_mc_ksa1[nrow(h_mc_ksa1) + 30,] <- NA
    forecast_mc_ksa1$r_orders <- h_mc_ksa1$y
    forecast_mc_ksa1$brand_country <- "mc_ksa"


    ####
    #### bbw_uae
    ###

    start_date <- Sys.Date() - 300
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176054247"
    h_bbw_uae1 <- google_analytics(ga_id,
                                   date_range = c(start_date, end_date),
                                   metrics = c("sessions", "transactions", "transactionsPerSession"),
                                   dimensions = "date")


    #rename col
    colnames(h_bbw_uae1) <- c("ds", "sessions", "y", "cvr")


    ### transform date
    h_bbw_uae1$ds <- as.Date(h_bbw_uae1$ds)

    #import promo calendar.
    promo_bbw_uae <- gsheet2tbl('https://docs.google.com/spreadsheets/d/1JFEodosUuVoKAtv596Gb2qrkUXst_VF8in9aek41fA8/edit?usp=sharing')


    ### start modeling
    m <- prophet(h_bbw_uae1, growth = "linear", changepoint.range = 0.9, daily.seasonality = TRUE, weekly.seasonality = TRUE,
                 holidays = promo_bbw_uae, seasonality.mode = "multiplicative",
                 changepoint.prior.scale = 0.7)
    future <- make_future_dataframe(m, periods = 30)
    forecast_bbw_uae1 <- predict(m, future)
    tail(forecast_bbw_uae1[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_bbw_uae1[nrow(h_bbw_uae1) + 30,] <- NA
    forecast_bbw_uae1$r_orders <- h_bbw_uae1$y
    forecast_bbw_uae1$brand_country <- "bbw_uae"


    ####
    #### bbw_ksa
    ###

    start_date <- Sys.Date() - 300
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176008893"
    h_bbw_ksa1 <- google_analytics(ga_id,
                                   date_range = c(start_date, end_date),
                                   metrics = c("sessions", "transactions", "transactionsPerSession"),
                                   dimensions = "date")


    #rename col
    colnames(h_bbw_ksa1) <- c("ds", "sessions", "y", "cvr")


    ### transform date
    h_bbw_ksa1$ds <- as.Date(h_bbw_ksa1$ds)

    #import promo calendar.
    promo_bbw_ksa <- gsheet2tbl('https://docs.google.com/spreadsheets/d/1Ly1i-L0Jkgv78vdgLFxJiExiqqlkkUxzvejvM57PlAU/edit?usp=sharing')


    ### start modeling
    m <- prophet(h_bbw_ksa1, growth = "linear", changepoint.range = 0.7, daily.seasonality = TRUE, weekly.seasonality = TRUE,
                 holidays = promo_bbw_uae, seasonality.mode = "multiplicative",
                 changepoint.prior.scale = 0.7)
    future <- make_future_dataframe(m, periods = 30)
    forecast_bbw_ksa1 <- predict(m, future)
    tail(forecast_bbw_ksa1[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_bbw_ksa1[nrow(h_bbw_ksa1) + 30,] <- NA
    forecast_bbw_ksa1$r_orders <- h_bbw_ksa1$y
    forecast_bbw_ksa1$brand_country <- "bbw_ksa"


    ####
    #### hm_ksa
    ###

    start_date <- Sys.Date() - 300
    end_date <- Sys.Date() - 1

    ga_id <- "ga:164870155"
    h_hm_ksa1 <- google_analytics(ga_id,
                                  date_range = c(start_date, end_date),
                                  metrics = c("sessions", "transactions", "transactionsPerSession"),
                                  dimensions = "date")


    #rename col
    colnames(h_hm_ksa1) <- c("ds", "sessions", "y", "cvr")


    ### transform date
    h_hm_ksa1$ds <- as.Date(h_hm_ksa1$ds)

    #import promo calendar.
    promo_hm_ksa <- gsheet2tbl('https://docs.google.com/spreadsheets/d/1T1CRulFxrPoEsvC3ykpbCGQEfnnlwwn5wu-5eNyHowc/edit?usp=sharing')


    ### start modeling
    m <- prophet(h_hm_ksa1, growth = "linear", changepoint.range = 0.7, daily.seasonality = TRUE, weekly.seasonality = TRUE,
                 holidays = promo_hm_ksa, seasonality.mode = "multiplicative",
                 changepoint.prior.scale = 0.7)
    future <- make_future_dataframe(m, periods = 30)
    forecast_hm_ksa1 <- predict(m, future)
    tail(forecast_hm_ksa1[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_hm_ksa1[nrow(h_hm_ksa1) + 30,] <- NA
    forecast_hm_ksa1$r_orders <- h_hm_ksa1$y
    forecast_hm_ksa1$brand_country <- "hm_ksa"


    ####
    #### hm_uae
    ###

    start_date <- Sys.Date() - 300
    end_date <- Sys.Date() - 1

    ga_id <- "ga:164862695"
    h_hm_uae1 <- google_analytics(ga_id,
                                  date_range = c(start_date, end_date),
                                  metrics = c("sessions", "transactions", "transactionsPerSession"),
                                  dimensions = "date")


    #rename col
    colnames(h_hm_uae1) <- c("ds", "sessions", "y", "cvr")


    ### transform date
    h_hm_uae1$ds <- as.Date(h_hm_uae1$ds)

    #import promo calendar.
    promo_hm_uae <- gsheet2tbl('https://docs.google.com/spreadsheets/d/1T1CRulFxrPoEsvC3ykpbCGQEfnnlwwn5wu-5eNyHowc/edit?usp=sharing')


    ### start modeling
    m <- prophet(h_hm_uae1, growth = "linear", changepoint.range = 0.7, daily.seasonality = TRUE, weekly.seasonality = TRUE,
                 holidays = promo_hm_uae, seasonality.mode = "multiplicative",
                 changepoint.prior.scale = 0.7)
    future <- make_future_dataframe(m, periods = 30)
    forecast_hm_uae1 <- predict(m, future)
    tail(forecast_hm_uae1[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_hm_uae1[nrow(h_hm_uae1) + 30,] <- NA
    forecast_hm_uae1$r_orders <- h_hm_uae1$y
    forecast_hm_uae1$brand_country <- "hm_uae"


    ###
    #### Merge All Data Frames.
    ####

    inner_forecast <- rbind(forecast_mc_uae1, forecast_mc_ksa1, forecast_bbw_uae1, forecast_bbw_ksa1,
                            forecast_hm_ksa1, forecast_hm_uae1)

    write.csv(inner_forecast, file = "inner_forecast.csv")


    #####
    #### Simulator Monster Machine
    ####

    df1 <- df_all %>% select(month_id, total_cost, session, brand, year_id)
    write.csv(df1, file = "df1.csv")
    print("Fetching Daily Forecast Data is done..")
}