library(googleAuthR)
library(gtrendsR)
library(lubridate)
library(dplyr)

get_gtrends_data <- function() {
    print("GA Trends data import started..")

    brand_countries <- c(
        "hm_uae", "hm_egy", "hm_ksa", "mc_uae", "mc_ksa", "bb_uae", "bb_ksa",
        "vs_uae", "vs_ksa", "we_uae", "pb_uae", "pb_ksa", "ae_uae", "ae_ksa",
        "mc_kwt", "fl_uae", "we_ksa", "hm_kwt", "fl_ksa")

    brand_countries_vector <- vector(mode = "list", length = 19)
    brand_gt_countries <- brand_countries_vector
    names(brand_gt_countries) <- brand_countries

    brand_gt_countries[[1]] <- "AE"
    brand_gt_countries[[2]] <- "EG"
    brand_gt_countries[[3]] <- "SA"
    brand_gt_countries[[4]] <- "AE"
    brand_gt_countries[[5]] <- "SA"
    brand_gt_countries[[6]] <- "AE"
    brand_gt_countries[[7]] <- "SA"
    brand_gt_countries[[8]] <- "AE"
    brand_gt_countries[[9]] <- "SA"
    brand_gt_countries[[10]] <- "AE"
    brand_gt_countries[[11]] <- "AE"
    brand_gt_countries[[12]] <- "SA"
    brand_gt_countries[[13]] <- "AE"
    brand_gt_countries[[14]] <- "SA"
    brand_gt_countries[[15]] <- "KW"
    brand_gt_countries[[16]] <- "AE"
    brand_gt_countries[[17]] <- "SA"
    brand_gt_countries[[18]] <- "KW"
    brand_gt_countries[[19]] <- "SA"

    brand_gt_keywords <- brand_countries_vector
    names(brand_gt_countries) <- brand_countries

    brand_gt_keywords[[1]] <- "hm"
    brand_gt_keywords[[2]] <- "hm"
    brand_gt_keywords[[3]] <- "hm"
    brand_gt_keywords[[4]] <- "mothercare"
    brand_gt_keywords[[5]] <- "mothercare"
    brand_gt_keywords[[6]] <- "bath body works"
    brand_gt_keywords[[7]] <- "bath body works"
    brand_gt_keywords[[8]] <- "victoria secret"
    brand_gt_keywords[[9]] <- "victoria secret"
    brand_gt_keywords[[10]] <- "west elm"
    brand_gt_keywords[[11]] <- "pottery barn"
    brand_gt_keywords[[12]] <- "pottery barn"
    brand_gt_keywords[[13]] <- "american eagle"
    brand_gt_keywords[[14]] <- "american eagle"
    brand_gt_keywords[[15]] <- "mothercare"
    brand_gt_keywords[[16]] <- "foot locker"
    brand_gt_keywords[[17]] <- "west elm"
    brand_gt_keywords[[18]] <- "hm"
    brand_gt_keywords[[19]] <- "foot locker"

    all_brand_country_gt_data <- list()
    df_sessions_data <- read.csv("df_sessions_i.csv", stringsAsFactors = F, header = T)

    for (i in seq_along(brand_gt_countries)) {
        brand_name_string <- names(brand_gt_countries)[[i]]
        country_code <- brand_gt_countries[[i]]
        brand_keyword <- brand_gt_keywords[[i]]

        print(brand_name_string)
        print(brand_keyword)

        brand_country_gt_data <- gtrends(keyword = brand_keyword,
                                         geo = country_code,
                                         time = "today 12-m")

        brand_country_gt_data <- brand_country_gt_data %>%
            .$interest_over_time %>%
            glimpse()
        brand_country_gt_data$brand_name <- brand_name_string

        brand_country_gt_date <- as_date(brand_country_gt_data$date)
        df <- data.frame("date" = brand_country_gt_date, "hits" = brand_country_gt_data$hits)
        dates <- seq.Date(min(brand_country_gt_date), max(brand_country_gt_date), by = 1)

        spline_func <- splinefun(x = df$date, y = df$hits, method = "fmm", ties = mean)
        spline_fit <- spline_func(dates)
        interpolated_hits <- data.frame("date" = dates, "hits" = spline_fit,
                                        "brand_name" = brand_name_string, "brand_keyword" = brand_keyword)

        df_sessions_brand_data <- subset(df_sessions_data, df_sessions_data$brand_name == brand_name_string)
        df_sessions_brand_data$date <- as_date(df_sessions_brand_data$date)

        print(df_sessions_brand_data[1:4,])
        print(interpolated_hits[1:4,])

        gt_sessions_brand_data <- df_sessions_brand_data %>% left_join(interpolated_hits, by = c("date", "brand_name"))
        gt_sessions_brand_data <- subset(gt_sessions_brand_data, (!is.na(gt_sessions_brand_data$organic_sessions)))

        max_organic_sessions <- max(gt_sessions_brand_data$organic_sessions, na.rm = TRUE)
        min_organic_sessions <- min(gt_sessions_brand_data$organic_sessions, na.rm = TRUE)

        max_hits <- max(gt_sessions_brand_data$hits, na.rm = TRUE)
        min_hits <- min(gt_sessions_brand_data$hits, na.rm = TRUE)

        gt_sessions_brand_data <- gt_sessions_brand_data %>%
            group_by(organic_sessions) %>%
            mutate(scaled_hits = (((max_organic_sessions - min_organic_sessions) * (hits - min_hits) /
                (max_hits - min_hits))))

        drops <- c("X.x", "X.y")
        gt_sessions_brand_data <- gt_sessions_brand_data[, !(names(gt_sessions_brand_data) %in% drops)]
        print(gt_sessions_brand_data[1:4,])

        all_brand_country_gt_data[[i]] <- gt_sessions_brand_data
    }

    brand_market_gt_data_all <- do.call(rbind, all_brand_country_gt_data)
    print(brand_market_gt_data_all)
    write.csv(brand_market_gt_data_all, file = "gtrends_data.csv")
    print("GA Trends data import finished..")
}
