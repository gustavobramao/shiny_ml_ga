library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)


get_paid_unpaid_gtrends <- function(){
    print("Fetching Paid/Unpaid Gtrends data..")

    start_date <- "2019-01-01"
    end_date <- Sys.Date()

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_hm_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_hm_ksa <- bq_table_download(offence_qtr)


    ###
    ### BBW KSA
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_bb_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_bbw_ksa <- bq_table_download(offence_qtr)


    ###
    ### MC KSA
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_mc_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_mc_ksa <- bq_table_download(offence_qtr)


    ###
    ### mc_uae
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_mc_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_mc_uae <- bq_table_download(offence_qtr)


    ###
    ### pb_ksa
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_pb_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_pb_ksa <- bq_table_download(offence_qtr)


    ###
    ### pb_uae
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_pb_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_pb_uae <- bq_table_download(offence_qtr)


    ###
    ### we_ksa
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_we_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_we_ksa <- bq_table_download(offence_qtr)

    ### cleaning data adding 0 to aggregate later

    time.points <- seq.Date(as.Date("2019-12-27"), by = 1, length.out = 79)
    date <- as.Date(time.points)
    date <- as.data.frame(date)

    brand_name <- "we_ksa"
    parent_grouping <- "UNPAID"
    sessions <- 0
    transaction <- 0


    data <- cbind(date, brand_name, parent_grouping, sessions, transaction)
    as.data.frame(data)

    time.points <- seq.Date(as.Date("2019-12-27"), by = 1, length.out = 108)
    date <- as.Date(time.points)
    date <- as.data.frame(date)

    brand_name <- "we_ksa"
    parent_grouping <- "PAID"
    sessions <- 0
    transaction <- 0


    data1 <- cbind(date, brand_name, parent_grouping, sessions, transaction)
    as.data.frame(data1)

    ga_we_ksat <- rbind(data, data1, ga_we_ksa)
    ga_we_ksat[is.na(ga_we_ksat)] <- 0


    ###
    ### we_uae
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_we_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_we_uae <- bq_table_download(offence_qtr)

    ### cleaning data adding 0 to aggregate later

    time.points <- seq.Date(as.Date("2019-12-27"), by = 1, length.out = 80)
    date <- as.Date(time.points)
    date <- as.data.frame(date)

    brand_name <- "we_uae"
    parent_grouping <- "UNPAID"
    sessions <- 0
    transaction <- 0


    data <- cbind(date, brand_name, parent_grouping, sessions, transaction)
    as.data.frame(data)

    time.points <- seq.Date(as.Date("2019-12-27"), by = 1, length.out = 108)
    date <- as.Date(time.points)
    date <- as.data.frame(date)

    brand_name <- "we_uae"
    parent_grouping <- "PAID"
    sessions <- 0
    transaction <- 0


    data1 <- cbind(date, brand_name, parent_grouping, sessions, transaction)
    as.data.frame(data1)

    ga_we_uaet <- rbind(data, data1, ga_we_uae)
    ga_we_uaet[is.na(ga_we_uaet)] <- 0


    ###
    ### bb_uae
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_bb_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_bb_uae <- bq_table_download(offence_qtr)


    ###
    ### hm_kwt
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_hm_kwt`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_hm_kwt <- bq_table_download(offence_qtr)


    ###
    ### hm_uae
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_hm_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_hm_uae <- bq_table_download(offence_qtr)


    ###
    ### mc_kwt
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_mc_kwt`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_mc_kwt <- bq_table_download(offence_qtr)


    ###
    ### fl_ksa
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_fl_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_fl_ksa <- bq_table_download(offence_qtr)


    ###
    ### fl_uae
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_fl_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_fl_uae <- bq_table_download(offence_qtr)


    ###
    ### vs_uae
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_vs_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_vs_uae <- bq_table_download(offence_qtr)


    ###
    ### vs_uae
    ###

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    parent_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_vs_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ga_vs_uae <- bq_table_download(offence_qtr)


    ### merge Ga data
    ga_sessions <- rbind(ga_bbw_ksa, ga_hm_ksa, ga_mc_ksa, ga_mc_uae, ga_pb_ksa,
                         ga_we_ksat, ga_pb_uae, ga_we_uaet, ga_bb_uae, ga_hm_kwt, ga_hm_uae,
                         ga_mc_kwt, ga_fl_ksa, ga_fl_uae, ga_vs_uae)

    ## Paid/Unpaid Grouping

    df_sessions <- ga_sessions %>% filter(parent_grouping == "PAID")
    df_sessions_i <- ga_sessions %>% filter(parent_grouping == "UNPAID")

    ## Aggregations and Sums

    df_sessions_i$paid_sessions <- df_sessions$sessions
    df_sessions_i$organic_sessions <- df_sessions_i$sessions
    df_sessions_i$total_transactions <- df_sessions$transaction + df_sessions_i$transaction
    df_sessions_i <- df_sessions_i %>% select(date, brand_name, paid_sessions, organic_sessions, total_transactions)

    write.csv(df_sessions_i, file = "df_sessions_i.csv")
    print("Fetching Paid/Unpaid Gtrends data is done..")
}