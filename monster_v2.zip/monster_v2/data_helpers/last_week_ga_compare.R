library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

get_last_week_ga_compare <- function(){
    ###
    ### Last week versus this week GA CvR BBW
    ###
    print("Fetching Last Week versus this week GA data CVR..")
    gar_set_client("secret.json", scopes = "https://www.googleapis.com/auth/analytics")

    start_date <- Sys.Date() - 8
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176008893"
    CvR_KSA_BBW_last_7 <- google_analytics(ga_id,
                                           date_range = c(start_date, end_date),
                                           metrics = c("sessions", "transactions", "transactionsPerSession"),
                                           dimensions = "dateHour")


    library(stringr)
    attach(CvR_KSA_BBW_last_7)
    CvR_KSA_BBW_last_7$dateHour <- as.POSIXct(paste(CvR_KSA_BBW_last_7$dateHour, "0000", sep = ""), format = "%Y%m%d%H%M%S")
    CvR_KSA_BBW_last_7$hours <- str_extract(CvR_KSA_BBW_last_7$dateHour, "........$")


    np1 <- CvR_KSA_BBW_last_7 %>%
        group_by(hours) %>%
        summarise(sessions = sum(sessions), transactions = sum(transactions))


    np1$transactionsPerSession <- np1$transactions / np1$sessions


    ###
    ### two week back
    ###


    start_date <- Sys.Date() - 15
    end_date <- Sys.Date() - 8


    ga_id <- "ga:176008893"
    CvR_KSA_BBW_last_7 <- google_analytics(ga_id,
                                           date_range = c(start_date, end_date),
                                           metrics = c("sessions", "transactions", "transactionsPerSession"),
                                           dimensions = "dateHour")

    #
    # Small transformation prior group by hours
    #

    library(stringr)
    attach(CvR_KSA_BBW_last_7)
    CvR_KSA_BBW_last_7$dateHour <- as.POSIXct(paste(CvR_KSA_BBW_last_7$dateHour, "0000", sep = ""), format = "%Y%m%d%H%M%S")
    CvR_KSA_BBW_last_7$hours <- str_extract(CvR_KSA_BBW_last_7$dateHour, "........$")


    nm1 <- CvR_KSA_BBW_last_7 %>%
        group_by(hours) %>%
        summarise(sessions = sum(sessions), transactions = sum(transactions))


    nm1$transactionsPerSession <- nm1$transactions / np1$sessions


    ##
    ## Loop to substract this week versus last week
    ##


    dateHour <- np1$hours
    sessions <- np1$sessions - nm1$sessions
    transactions <- np1$transactions - nm1$transactions
    transactionsPerSession <- np1$transactionsPerSession - nm1$transactionsPerSession

    bbw_ksa_7 <- cbind(dateHour, sessions, transactions, transactionsPerSession)

    bbw_ksa_7 <- as.data.frame(bbw_ksa_7)
    colnames(bbw_ksa_7) <- c("hour", "sessions", "transactions", "transactionsPerSession")


    #### export bbw_ksa
    write.csv(bbw_ksa_7, file = "bbw_ksa_cvr.csv")


    ###
    ### Last week versus this week GA CvR BBW
    ###


    start_date <- Sys.Date() - 8
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176054247"
    CvR_UAE_BBW_last_7 <- google_analytics(ga_id,
                                           date_range = c(start_date, end_date),
                                           metrics = c("sessions", "transactions", "transactionsPerSession"),
                                           dimensions = "dateHour")


    library(stringr)
    attach(CvR_UAE_BBW_last_7)
    CvR_UAE_BBW_last_7$dateHour <- as.POSIXct(paste(CvR_UAE_BBW_last_7$dateHour, "0000", sep = ""), format = "%Y%m%d%H%M%S")
    CvR_UAE_BBW_last_7$hours <- str_extract(CvR_UAE_BBW_last_7$dateHour, "........$")


    np1 <- CvR_UAE_BBW_last_7 %>%
        group_by(hours) %>%
        summarise(sessions = sum(sessions), transactions = sum(transactions))


    np1$transactionsPerSession <- np1$transactions / np1$sessions


    ###
    ### two week back
    ###


    start_date <- Sys.Date() - 15
    end_date <- Sys.Date() - 8


    ga_id <- "ga:176054247"
    CvR_UAE_BBW_last_7 <- google_analytics(ga_id,
                                           date_range = c(start_date, end_date),
                                           metrics = c("sessions", "transactions", "transactionsPerSession"),
                                           dimensions = "dateHour")

    #
    # Small transformation prior group by hours
    #

    library(stringr)
    attach(CvR_UAE_BBW_last_7)
    CvR_UAE_BBW_last_7$dateHour <- as.POSIXct(paste(CvR_UAE_BBW_last_7$dateHour, "0000", sep = ""), format = "%Y%m%d%H%M%S")
    CvR_UAE_BBW_last_7$hours <- str_extract(CvR_UAE_BBW_last_7$dateHour, "........$")


    nm1 <- CvR_UAE_BBW_last_7 %>%
        group_by(hours) %>%
        summarise(sessions = sum(sessions), transactions = sum(transactions))


    nm1$transactionsPerSession <- nm1$transactions / np1$sessions


    ##
    ## Loop to substract this week versus last week
    ##


    dateHour <- np1$hours
    sessions <- np1$sessions - nm1$sessions
    transactions <- np1$transactions - nm1$transactions
    transactionsPerSession <- np1$transactionsPerSession - nm1$transactionsPerSession

    bbw_uae_7 <- cbind(dateHour, sessions, transactions, transactionsPerSession)

    bbw_uae_7 <- as.data.frame(bbw_uae_7)
    colnames(bbw_uae_7) <- c("hour", "sessions", "transactions", "transactionsPerSession")


    #### export bbw_ksa
    write.csv(bbw_uae_7, file = "bbw_uae_cvr.csv")
    print("Fetching Last Week versus this week GA data CVR is done..")
}