hm_gtrends <- gtrends(keyword = "hm",
                      geo = "SA",
                      time = "today 12-m")


hm_gtrends <- hm_gtrends %>%
    .$interest_over_time %>%
    glimpse()


hm_gtrends$brand_country <- "hm_ksa"

print("all_brands_pull script exection is done..")