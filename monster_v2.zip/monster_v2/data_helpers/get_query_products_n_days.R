library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

get_query_products_n_days_before <- function(){
    print("Fetching data N Days before from Magento BQ..")
    ###
    ### Query Products -7
    ###

    start_date_7 <- Sys.Date() - 7
    end_date_7 <- Sys.Date()

    bq_conn <- get_bq_conn()
    bigrquery::dbListTables(bq_conn)

    sql_query <- sprintf("SELECT
    sku,
    name,
    store_id,
    count(sku) as total,
    sum(base_price) as base_price,
    sum(base_discount_amount) as base_discount,
    sum(base_original_price) as orginal_price,
    sum(qty_ordered) as quantity_ordered

    FROM `authentic-codex-225113.magento_bbw.order_items` WHERE created_at between '%s' and '%s'

    group by 1,2,3

    order by 1 asc, 3 desc", start_date_7, end_date_7)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_bbw_products <- bq_table_download(offence_qtr)
    write.csv(df_bbw_products, file = "df_bbw_products.csv")


    ###
    ### Query Products -14
    ###

    start_date_14 <- Sys.Date() - 14
    end_date_14 <- Sys.Date() - 7


    bigrquery::dbListTables(bq_conn)

    sql_query <- sprintf("SELECT
    sku,
    name,
    store_id,
    count(sku) as total,
    sum(base_price) as base_price,
    sum(base_discount_amount) as base_discount,
    sum(base_original_price) as orginal_price,
    sum(qty_ordered) as quantity_ordered

    FROM `authentic-codex-225113.magento_bbw.order_items` WHERE created_at between '%s' and '%s'

    group by 1,2,3

    order by 1 asc, 3 desc", start_date_14, end_date_14)


    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_bbw_products_14 <- bq_table_download(offence_qtr)
    write.csv(df_bbw_products_14, file = "df_bbw_products_14.csv")
    print("Fetching data N Days before from Magento BQ is Done..")
}