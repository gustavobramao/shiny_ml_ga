library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

get_ga_sessions_transactions <- function(){
    print("Fetching GA Sessions & Transactions Data..")

    #### HM KSA
    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:164870155"
    hm_ksa <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")


    hm_ksa$brand_country <- "hm_ksa"


    ### HM UAE


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:164862695"
    hm_uae <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")


    hm_uae$brand_country <- "hm_uae"


    ### HM EGY


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:205050928"
    hm_egy <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")


    hm_egy$brand_country <- "hm_egy"


    ### MC UAE


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:114955062"
    mc_uae <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")


    mc_uae$brand_country <- "mc_uae"


    ### MC KSA


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:114976409"
    mc_ksa <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")


    mc_ksa$brand_country <- "mc_ksa"


    ### BBW UAE


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176054247"
    bbw_uae <- google_analytics(ga_id,
                                date_range = c(start_date, end_date),
                                metrics = c("sessions", "transactions"),
                                dimensions = "date")


    bbw_uae$brand_country <- "bbw_uae"


    ### BBW KSA


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176008893"
    bbw_ksa <- google_analytics(ga_id,
                                date_range = c(start_date, end_date),
                                metrics = c("sessions", "transactions"),
                                dimensions = "date")


    bbw_ksa$brand_country <- "bbw_ksa"


    ### VS UAE


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176079653"
    vs_uae <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")


    vs_uae$brand_country <- "vs_uae"


    ### VS KSA


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176080378"
    vs_ksa <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")

    vs_ksa$brand_country <- "vs_ksa"


    ### WES UAE


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:203456336"
    wes_uae <- google_analytics(ga_id,
                                date_range = c(start_date, end_date),
                                metrics = c("sessions", "transactions"),
                                dimensions = "date")

    wes_uae$brand_country <- "wes_uae"


    ### WES KSA


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:203501911"
    wes_ksa <- google_analytics(ga_id,
                                date_range = c(start_date, end_date),
                                metrics = c("sessions", "transactions"),
                                dimensions = "date")

    wes_uae$brand_country <- "wes_ksa"


    ### PB UAE


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:188370045"
    pb_uae <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")

    pb_uae$brand_country <- "pb_uae"


    ### PB KSA


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:197344933"
    pb_ksa <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")

    pb_ksa$brand_country <- "pb_ksa"


    ### AEO UAE


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:214221282"
    aeo_uae <- google_analytics(ga_id,
                                date_range = c(start_date, end_date),
                                metrics = c("sessions", "transactions"),
                                dimensions = "date")

    aeo_uae$brand_country <- "aeo_uae"


    ### AEO KSA

    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:214218311"
    aeo_ksa <- google_analytics(ga_id,
                                date_range = c(start_date, end_date),
                                metrics = c("sessions", "transactions"),
                                dimensions = "date")

    aeo_ksa$brand_country <- "aeo_ksa"


    ### BBW UAE


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176054247"
    bbw_uae <- google_analytics(ga_id,
                                date_range = c(start_date, end_date),
                                metrics = c("sessions", "transactions"),
                                dimensions = "date")

    bbw_uae$brand_country <- "bbw_uae"


    ### BBW KSA


    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176008893"
    bbw_ksa <- google_analytics(ga_id,
                                date_range = c(start_date, end_date),
                                metrics = c("sessions", "transactions"),
                                dimensions = "date")

    bbw_ksa$brand_country <- "bbw_ksa"


    ### MC KWT

    start_date <- Sys.Date() - 100
    end_date <- Sys.Date() - 1

    ga_id <- "ga:114973213"
    mc_kwt <- google_analytics(ga_id,
                               date_range = c(start_date, end_date),
                               metrics = c("sessions", "transactions"),
                               dimensions = "date")

    mc_kwt$brand_country <- "mc_kwt"

    ### merge all DFs.

    inner_ga <- rbind(hm_ksa, hm_uae, hm_egy, mc_ksa, mc_uae, mc_kwt, pb_uae, pb_ksa, bbw_uae, bbw_ksa)

    write.csv(inner_ga, file = "iga.csv")
    print("Fetching GA Sessions & Transactions Data is done..")
}