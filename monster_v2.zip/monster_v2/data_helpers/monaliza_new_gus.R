library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
  "https://www.googleapis.com/auth/bigquery",
  "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

monaliza_new_gus <- function(){
  print("Fetching data from Monaliza and preparing Macro Bands..")
  ###
  ### ----- Filter Date
  ###
  start_date <- "2019-01-01"
  end_date <- Sys.Date()
  
  ###
  ### ----  Query all brands and
  ###
  
  # BigQuery Auth
  bq_conn <- get_bq_conn()
  bigrquery::dbListTables(bq_conn)
  
  sql_query <- sprintf("SELECT*
    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where date between '%s' and '%s'
    order by date asc", start_date, end_date)
  
  
  offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
  df_all <- bq_table_download(offence_qtr)
  
  df_all$gm_per_cent <- df_all$gross_margin / df_all$gross_revenue
  df_all$total_cost <- df_all$cost + df_all$affiliate_cost
  df_all$CvR <- df_all$orders / df_all$session
  write.csv(df_all, file = "df_all.csv")
  
  ###
  ### Group data frame by brand to plot clean later-on
  ###
  
  macro_brand <- df_all %>% dplyr::select(date, orders, brand, session, gross_revenue, gross_margin, cost, affiliate_cost, facebook_costs, adwords_costs, criteo_costs, snapchat_costs
                    ,partnerize_costs, sms_costs) 
  macro_brand <- macro_brand %>%
  group_by(date, brand) %>%
  summarise_all(funs(sum))
  
  ### Aggregated sum
  
  macro_brand$gm_per_cent <- macro_brand$gross_margin / macro_brand$gross_revenue
  macro_brand$total_cost <- macro_brand$cost + macro_brand$affiliate_cost
  macro_brand$CvR <- macro_brand$orders / macro_brand$session
  macro_brand$CiR <- macro_brand$total_cost / macro_brand$gross_revenue
  macro_brand$CPV <- macro_brand$total_cost / macro_brand$session
  macro_brand[is.na(macro_brand)] <- 0
  
  write.csv(macro_brand, file = "macro1.csv")
  
  
  
  
  ###
  ### Group data frame by brand to plot clean later-on
  ###
  
  macro_brand_country <- df_all %>% dplyr::select(date, orders, brand_country, session, gross_revenue, gross_margin, cost, affiliate_cost, facebook_costs, adwords_costs, criteo_costs, snapchat_costs
                                          ,partnerize_costs, sms_costs) 
  macro_brand_country <- macro_brand_country %>%
    group_by(date, brand_country) %>%
    summarise_all(funs(sum))
  
  macro_brand_country$gm_per_cent <- macro_brand_country$gross_margin / macro_brand_country$gross_revenue
  macro_brand_country$total_cost <- macro_brand_country$cost + macro_brand_country$affiliate_cost
  macro_brand_country$CvR <- macro_brand_country$orders / macro_brand_country$session
  macro_brand_country$CiR <- macro_brand_country$total_cost / macro_brand_country$gross_revenue
  macro_brand_country$CPV <- macro_brand_country$total_cost / macro_brand_country$session
  macro_brand_country[is.na(macro_brand_country)] <- 0
  
  write.csv(macro_brand_country, file = "macro2.csv")
  
  #return(macro_brand_c)
  print("Fetching data from Monaliza and preparing Macro Bands is done..")
}