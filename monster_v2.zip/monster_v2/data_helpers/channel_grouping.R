library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)


get_channel_grouping <- function(){
    print("Fetching Channel Grouping data..")
    start_date <- "2019-01-01"
    end_date <- Sys.Date()

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    child_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_hm_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ch_hm_uae <- bq_table_download(offence_qtr)
    ch_hm_uae[is.na(ch_hm_uae)] <- 0

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    child_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_hm_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ch_hm_ksa <- bq_table_download(offence_qtr)
    ch_hm_ksa[is.na(ch_hm_ksa)] <- 0

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    child_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_bb_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ch_bbw_ksa <- bq_table_download(offence_qtr)
    ch_bbw_ksa[is.na(ch_bbw_ksa)] <- 0

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    child_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_bb_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ch_bbw_uae <- bq_table_download(offence_qtr)
    ch_bbw_uae[is.na(ch_bbw_uae)] <- 0

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    child_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_mc_uae`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ch_mc_uae <- bq_table_download(offence_qtr)
    ch_mc_uae[is.na(ch_mc_uae)] <- 0

    sql_query <- sprintf("SELECT
    date,
    brand_name,
    child_grouping,
    SUM(Session) as sessions,
    SUM(Transaction) as transaction
    FROM `authentic-codex-225113.ga_channels.channels_mc_ksa`
    group by 1,2,3

    order by 1 asc", start_date, end_date)
    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    ch_mc_ksa <- bq_table_download(offence_qtr)
    ch_mc_ksa[is.na(ch_mc_ksa)] <- 0##

    channel <- rbind(ch_hm_uae, ch_hm_ksa, ch_bbw_ksa, ch_bbw_uae, ch_mc_uae, ch_mc_ksa)
    Organic_Social <- channel %>% filter(child_grouping == "Organic Social")
    Organic <- channel %>% filter(child_grouping == "Organic")
    Brand_Paid_Search <- channel %>% filter(child_grouping == "Brand Paid Search")
    Non_Brand_Paid_Search <- dplyr::filter(channel, grepl('^Non', child_grouping))
    Facebook <- channel %>% filter(child_grouping == "Facebook")
    Snapchat <- channel %>% filter(child_grouping == "Snapchat")
    Others <- channel %>% filter(child_grouping == "Others")
    Referral <- channel %>% filter(child_grouping == "Referral")
    Affiliate <- channel %>% filter(child_grouping == "Affiliate")
    DCM <- channel %>% filter(child_grouping == "DCM")
    SMS <- channel %>% filter(child_grouping == "SMS")
    Criteo <- channel %>% filter(child_grouping == "Criteo")
    Direct <- channel %>% filter(child_grouping == "Direct")
    GDN <- channel %>% filter(child_grouping == "GDN")
    Email <- channel %>% filter(child_grouping == "Email")
    Wpush <- channel %>% filter(child_grouping == "Wpush")

    ### Final transformation

    Organic$CvR <- Direct$transaction / Direct$sessions
    Organic$Organic <- Organic$sessions
    Organic$Organic_Social <- Organic_Social$sessions
    Organic$Non_Brand_Paid_Search <- Non_Brand_Paid_Search$sessions
    Organic$Facebook <- Facebook$sessions
    Organic$Brand_Paid_Search <- Brand_Paid_Search$sessions
    Organic$Affiliate <- Affiliate$sessions

    write.csv(Organic, file = "organic.csv")
    print("Fetching Channel Grouping data is done..")

}