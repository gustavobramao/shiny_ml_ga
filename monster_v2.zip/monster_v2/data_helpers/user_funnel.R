library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

get_user_funnel_data <- function(){
    #### BBW KSA Historical
    print("Fetching User Funnel Data..")
    start_date <- Sys.Date() - 100
    end_date <- Sys.Date()

    ga_id <- "ga:176008893"
    f_bbw_ksa <- google_analytics(ga_id,
                                  date_range = c(start_date, end_date),
                                  metrics = c("users"),
                                  dimensions = "shoppingStage")

    f_bbw_ksa <- f_bbw_ksa %>% filter(shoppingStage == "ALL_VISITS" |
                                          shoppingStage == "PRODUCT_VIEW"
                                          |
                                          shoppingStage == "CHECKOUT_1" |
                                          shoppingStage == "CHECKOUT_2" |
                                          shoppingStage == "CHECKOUT_3" |
                                          shoppingStage == "TRANSACTION")

    f_bbw_ksa$brand_country <- "bbw_ksa"
    f_bbw_ksa <- f_bbw_ksa %>% arrange(desc(f_bbw_ksa$users))


    #### BBW KSA 7 days

    start_date <- Sys.Date() - 7
    end_date <- Sys.Date()

    ga_id <- "ga:176008893"
    f_bbw_ksa7 <- google_analytics(ga_id,
                                   date_range = c(start_date, end_date),
                                   metrics = c("users"),
                                   dimensions = "shoppingStage")

    f_bbw_ksa7 <- f_bbw_ksa7 %>% filter(shoppingStage == "ALL_VISITS" |
                                            shoppingStage == "PRODUCT_VIEW"
                                            |
                                            shoppingStage == "CHECKOUT_1" |
                                            shoppingStage == "CHECKOUT_2" |
                                            shoppingStage == "CHECKOUT_3" |
                                            shoppingStage == "TRANSACTION")
    f_bbw_ksa7$brand_country <- "bbw_ksa"
    f_bbw_ksa7 <- f_bbw_ksa7 %>% arrange(desc(f_bbw_ksa7$users))


    #### BBW KSA Today

    start_date <- Sys.Date() - 1
    end_date <- Sys.Date()

    ga_id <- "ga:176008893"
    f_bbw_ksat <- google_analytics(ga_id,
                                   date_range = c(start_date, end_date),
                                   metrics = c("users"),
                                   dimensions = "shoppingStage")

    f_bbw_ksat <- f_bbw_ksat %>% filter(shoppingStage == "ALL_VISITS" |
                                            shoppingStage == "PRODUCT_VIEW"
                                            |
                                            shoppingStage == "CHECKOUT_1" |
                                            shoppingStage == "CHECKOUT_2" |
                                            shoppingStage == "CHECKOUT_3" |
                                            shoppingStage == "TRANSACTION")
    f_bbw_ksat$brand_country <- "bbw_ksa"
    f_bbw_ksat <- f_bbw_ksat %>% arrange(desc(f_bbw_ksat$users))


    #### bbw_uae Historical

    start_date <- Sys.Date() - 100
    end_date <- Sys.Date()

    ga_id <- "ga:176054247"
    f_bbw_uae <- google_analytics(ga_id,
                                  date_range = c(start_date, end_date),
                                  metrics = c("users"),
                                  dimensions = "shoppingStage")

    f_bbw_uae <- f_bbw_uae %>% filter(shoppingStage == "ALL_VISITS" |
                                          shoppingStage == "PRODUCT_VIEW"
                                          |
                                          shoppingStage == "CHECKOUT_1" |
                                          shoppingStage == "CHECKOUT_2" |
                                          shoppingStage == "CHECKOUT_3" |
                                          shoppingStage == "TRANSACTION")

    f_bbw_uae$brand_country <- "bbw_uae"
    f_bbw_uae <- f_bbw_uae %>% arrange(desc(f_bbw_uae$users))


    #### bbw_uae 7 days

    start_date <- Sys.Date() - 7
    end_date <- Sys.Date()

    ga_id <- "ga:176054247"
    f_bbw_uae7 <- google_analytics(ga_id,
                                   date_range = c(start_date, end_date),
                                   metrics = c("users"),
                                   dimensions = "shoppingStage")

    f_bbw_uae7 <- f_bbw_uae7 %>% filter(shoppingStage == "ALL_VISITS" |
                                            shoppingStage == "PRODUCT_VIEW"
                                            |
                                            shoppingStage == "CHECKOUT_1" |
                                            shoppingStage == "CHECKOUT_2" |
                                            shoppingStage == "CHECKOUT_3" |
                                            shoppingStage == "TRANSACTION")

    f_bbw_uae7$brand_country <- "bbw_uae"
    f_bbw_uae7 <- f_bbw_uae7 %>% arrange(desc(f_bbw_uae7$users))


    #### bbw_uae Today

    start_date <- Sys.Date() - 1
    end_date <- Sys.Date()

    ga_id <- "ga:176054247"
    f_bbw_uaet <- google_analytics(ga_id,
                                   date_range = c(start_date, end_date),
                                   metrics = c("users"),
                                   dimensions = "shoppingStage")

    f_bbw_uaet <- f_bbw_uaet %>% filter(shoppingStage == "ALL_VISITS" |
                                            shoppingStage == "PRODUCT_VIEW"
                                            |
                                            shoppingStage == "CHECKOUT_1" |
                                            shoppingStage == "CHECKOUT_2" |
                                            shoppingStage == "CHECKOUT_3" |
                                            shoppingStage == "TRANSACTION")

    f_bbw_uaet$brand_country <- "bbw_uae"
    f_bbw_uaet <- f_bbw_uaet %>% arrange(desc(f_bbw_uaet$users))


    #### merge
    funnel_historical <- rbind(f_bbw_uae, f_bbw_ksa)
    write.csv(funnel_historical, file = "funnel_historical.csv")


    #### merge
    funnel7 <- rbind(f_bbw_uae7, f_bbw_ksa7)
    write.csv(funnel7, file = "funnel7.csv")


    #### merge
    funnelt <- rbind(f_bbw_uaet, f_bbw_ksat)
    write.csv(funnelt, file = "funnelt.csv")
    print("Fetching User Funnel Data is done..")
}