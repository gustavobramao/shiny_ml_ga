library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

get_products_performance <- function(){
    ####
    #### BBW KSA
    ###
    print("Fetching Products Performance Data..")

    start_date <- Sys.Date() - 7
    end_date <- Sys.Date()

    ga_id <- "ga:176008893"
    bbw_ksa_product_after_SAS <- google_analytics(ga_id,
                                                  date_range = c(start_date, end_date),
                                                  metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                                  dimensions = c("productSku", "productName"),
                                                  anti_sample = TRUE)

    bbw_ksa_product_after_SAS$brand_country <- "bbw_ksa"


    bbw_ksa_product_after_SAS <- bbw_ksa_product_after_SAS %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ####
    #### BBW KSA
    ###

    start_date <- Sys.Date() - 40
    end_date <- Sys.Date() - 10

    ga_id <- "ga:176008893"
    bbw_ksa_product <- google_analytics(ga_id,
                                        date_range = c(start_date, end_date),
                                        metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                        dimensions = c("productSku", "productName"),
                                        anti_sample = TRUE)


    bbw_ksa_product$brand_country <- "bbw_ksa"

    bbw_ksa_product <- bbw_ksa_product %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ####
    #### FL UAE ----- --
    ###

    start_date <- Sys.Date() - 7
    end_date <- Sys.Date()

    ga_id <- "ga:197083733"
    fl_uae_product_after_SAS <- google_analytics(ga_id,
                                                 date_range = c(start_date, end_date),
                                                 metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                                 dimensions = c("productSku", "productName"),
                                                 anti_sample = TRUE)


    fl_uae_product_after_SAS$brand_country <- "fl_uae"
    fl_uae_product_after_SAS <- fl_uae_product_after_SAS %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ####
    #### FL UAE --- -----
    ###

    start_date <- Sys.Date() - 40
    end_date <- Sys.Date() - 10

    ga_id <- "ga:197083733"
    fl_uae_product <- google_analytics(ga_id,
                                       date_range = c(start_date, end_date),
                                       metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                       dimensions = c("productSku", "productName"),
                                       anti_sample = TRUE)


    fl_uae_product$brand_country <- "fl_uae"
    fl_uae_product <- fl_uae_product %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ####
    #### VS UAE -------
    ###

    start_date <- Sys.Date() - 7
    end_date <- Sys.Date()

    ga_id <- "ga:176079653"
    vs_uae_product_after_SAS <- google_analytics(ga_id,
                                                 date_range = c(start_date, end_date),
                                                 metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                                 dimensions = c("productSku", "productName"),
                                                 anti_sample = TRUE)


    vs_uae_product_after_SAS$brand_country <- "vs_uae"
    vs_uae_product_after_SAS <- vs_uae_product_after_SAS %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ####
    #### VS UAE --- -----
    ###

    start_date <- Sys.Date() - 40
    end_date <- Sys.Date() - 10

    ga_id <- "ga:176079653"
    vs_uae_product <- google_analytics(ga_id,
                                       date_range = c(start_date, end_date),
                                       metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                       dimensions = c("productSku", "productName"),
                                       anti_sample = TRUE)


    vs_uae_product$brand_country <- "vs_uae"
    vs_uae_product <- vs_uae_product %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ####
    #### HM UAE -------
    ###

    start_date <- Sys.Date() - 7
    end_date <- Sys.Date()

    ga_id <- "ga:164862695"
    hm_uae_product_after_SAS <- google_analytics(ga_id,
                                                 date_range = c(start_date, end_date),
                                                 metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                                 dimensions = c("productSku", "productName"),
                                                 anti_sample = TRUE)


    hm_uae_product_after_SAS$brand_country <- "hm_uae"
    hm_uae_product_after_SAS <- hm_uae_product_after_SAS %>%
        filter(rank(desc(itemRevenue)) <= 50)


    start_date <- Sys.Date() - 40
    end_date <- Sys.Date() - 10

    ga_id <- "ga:164862695"
    hm_uae_product <- google_analytics(ga_id,
                                       date_range = c(start_date, end_date),
                                       metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                       dimensions = c("productSku", "productName"),
                                       anti_sample = TRUE)


    hm_uae_product$brand_country <- "hm_uae"
    hm_uae_product <- hm_uae_product %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ####
    #### MC KSA
    ###

    start_date <- Sys.Date() - 7
    end_date <- Sys.Date()

    ga_id <- "ga:114976409"
    mc_ksa_product_after_SAS <- google_analytics(ga_id,
                                                 date_range = c(start_date, end_date),
                                                 metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                                 dimensions = c("productSku", "productName"),
                                                 anti_sample = TRUE)

    mc_ksa_product_after_SAS$brand_country <- "mc_ksa"


    mc_ksa_product_after_SAS <- mc_ksa_product_after_SAS %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ####
    #### MC KSA
    ###

    start_date <- Sys.Date() - 40
    end_date <- Sys.Date() - 10

    ga_id <- "ga:114976409"
    mc_ksa_product <- google_analytics(ga_id,
                                       date_range = c(start_date, end_date),
                                       metrics = c("itemRevenue", "productListCTR", "productListClicks", "buyToDetailRate"),
                                       dimensions = c("productSku", "productName"),
                                       anti_sample = TRUE)


    mc_ksa_product$brand_country <- "mc_ksa"

    mc_ksa_product <- mc_ksa_product %>%
        filter(rank(desc(itemRevenue)) <= 50)


    ### merge all DFs.

    products_after_SAS <- rbind(fl_uae_product_after_SAS, bbw_ksa_product_after_SAS, vs_uae_product_after_SAS,
                                hm_uae_product_after_SAS, mc_ksa_product_after_SAS)

    write.csv(products_after_SAS, file = "bb2.csv")

    product <- rbind(fl_uae_product, bbw_ksa_product, vs_uae_product, hm_uae_product, mc_ksa_product)
    write.csv(product, file = "pr2.csv")
    print("Fetching Products Performance Data is Done..")
}
