library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

get_hourly_forecast <- function(){
    print("Fetching hourly forcast by prophet..")

    start_date <- Sys.Date() - 8
    end_date <- Sys.Date() - 1

    ga_id <- "ga:176054247"
    h_bbw_uae <- google_analytics(ga_id,
                                  date_range = c(start_date, end_date),
                                  metrics = c("sessions", "transactions", "transactionsPerSession"),
                                  dimensions = "dateHour")


    colnames(h_bbw_uae) <- c("ds", "sessions", "y", "cvr")


    ### Regex transform date

    x <- h_bbw_uae$ds
    y <- sub("\\s+$", "", gsub('(.{8})', '\\1 ', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(^.{4})', '\\1-', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(.{7})', '\\1-', x))

    y1 <- y

    x <- y1
    y <- sub("\\s+$", "", gsub('(.{13})', '\\1:00:00', x))

    h_bbw_uae$ds <- y


    ### start modeling
    m <- prophet(h_bbw_uae, growth = "linear", changepoint.range = 0.5,
                 yearly.seasonality = "TRUE", weekly.seasonality = "TRUE",
                 daily.seasonality = "TRUE", holidays = NULL,
                 seasonality.mode = "multiplicative", seasonality.prior.scale = 50,
                 holidays.prior.scale = 10, changepoint.prior.scale = 0.2,
                 mcmc.samples = 0, interval.width = 0.8, uncertainty.samples = 1000,
                 fit = TRUE)


    future <- make_future_dataframe(m, periods = 30, freq = 60 * 60)
    forecast_bbw_uae <- predict(m, future)
    tail(forecast_bbw_uae[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_bbw_uae[nrow(h_bbw_uae) + 30,] <- NA
    forecast_bbw_uae$r_orders <- h_bbw_uae$y
    forecast_bbw_uae$brand_country <- "bbw_uae"


    #####
    #### Hourly forecast_b_ksa
    ###


    start_date <- Sys.Date() - 8
    end_date <- Sys.Date()

    ga_id <- "ga:176008893"
    h_bbw_ksa <- google_analytics(ga_id,
                                  date_range = c(start_date, end_date),
                                  metrics = c("sessions", "transactions", "transactionsPerSession"),
                                  dimensions = "dateHour")


    colnames(h_bbw_ksa) <- c("ds", "sessions", "y", "cvr")


    ### Regex transform date

    x <- h_bbw_ksa$ds
    y <- sub("\\s+$", "", gsub('(.{8})', '\\1 ', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(^.{4})', '\\1-', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(.{7})', '\\1-', x))

    y1 <- y

    x <- y1
    y <- sub("\\s+$", "", gsub('(.{13})', '\\1:00:00', x))

    h_bbw_ksa$ds <- y


    ### start modeling
    m <- prophet(h_bbw_ksa, growth = "linear", changepoint.range = 0.5,
                 yearly.seasonality = "TRUE", weekly.seasonality = "TRUE",
                 daily.seasonality = "TRUE", holidays = NULL,
                 seasonality.mode = "multiplicative", seasonality.prior.scale = 50,
                 holidays.prior.scale = 10, changepoint.prior.scale = 0.2,
                 mcmc.samples = 0, interval.width = 0.8, uncertainty.samples = 1000,
                 fit = TRUE)


    future <- make_future_dataframe(m, periods = 30, freq = 60 * 60)
    forecast_bbw_ksa <- predict(m, future)
    tail(forecast_bbw_ksa[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_bbw_ksa[nrow(h_bbw_ksa) + 30,] <- NA
    forecast_bbw_ksa$r_orders <- h_bbw_ksa$y
    forecast_bbw_ksa$brand_country <- "bbw_ksa"


    #####
    #### Hourly forecast_bbw_uae
    ###


    start_date <- Sys.Date() - 8
    end_date <- Sys.Date()

    ga_id <- "ga:164862695"
    h_hm_uae <- google_analytics(ga_id,
                                 date_range = c(start_date, end_date),
                                 metrics = c("sessions", "transactions", "transactionsPerSession"),
                                 dimensions = "dateHour")


    colnames(h_hm_uae) <- c("ds", "sessions", "y", "cvr")


    ### Regex transform date

    x <- h_hm_uae$ds
    y <- sub("\\s+$", "", gsub('(.{8})', '\\1 ', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(^.{4})', '\\1-', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(.{7})', '\\1-', x))

    y1 <- y

    x <- y1
    y <- sub("\\s+$", "", gsub('(.{13})', '\\1:00:00', x))

    h_hm_uae$ds <- y


    ### start modeling
    m <- prophet(h_hm_uae, growth = "linear", changepoint.range = 0.5,
                 yearly.seasonality = "TRUE", weekly.seasonality = "TRUE",
                 daily.seasonality = "TRUE", holidays = NULL,
                 seasonality.mode = "multiplicative", seasonality.prior.scale = 50,
                 holidays.prior.scale = 10, changepoint.prior.scale = 0.2,
                 mcmc.samples = 0, interval.width = 0.8, uncertainty.samples = 1000,
                 fit = TRUE)


    future <- make_future_dataframe(m, periods = 30, freq = 60 * 60)
    forecast_hm_uae <- predict(m, future)
    tail(forecast_hm_uae[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_hm_uae[nrow(h_hm_uae) + 30,] <- NA
    forecast_hm_uae$r_orders <- h_hm_uae$y
    forecast_hm_uae$brand_country <- "hm_uae"


    #####
    #### Hourly forecast_bbw_uae
    ###


    start_date <- Sys.Date() - 8
    end_date <- Sys.Date()

    ga_id <- "ga:205050928"
    h_hm_egy <- google_analytics(ga_id,
                                 date_range = c(start_date, end_date),
                                 metrics = c("sessions", "transactions", "transactionsPerSession"),
                                 dimensions = "dateHour")


    colnames(h_hm_egy) <- c("ds", "sessions", "y", "cvr")


    ### Regex transform date

    x <- h_hm_egy$ds
    y <- sub("\\s+$", "", gsub('(.{8})', '\\1 ', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(^.{4})', '\\1-', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(.{7})', '\\1-', x))

    y1 <- y

    x <- y1
    y <- sub("\\s+$", "", gsub('(.{13})', '\\1:00:00', x))

    h_hm_egy$ds <- y


    ### start modeling
    m <- prophet(h_hm_egy, growth = "linear", changepoint.range = 0.5,
                 yearly.seasonality = "TRUE", weekly.seasonality = "TRUE",
                 daily.seasonality = "TRUE", holidays = NULL,
                 seasonality.mode = "multiplicative", seasonality.prior.scale = 50,
                 holidays.prior.scale = 10, changepoint.prior.scale = 0.2,
                 mcmc.samples = 0, interval.width = 0.8, uncertainty.samples = 1000,
                 fit = TRUE)


    future <- make_future_dataframe(m, periods = 30, freq = 60 * 60)
    forecast_hm_egy <- predict(m, future)
    tail(forecast_hm_egy[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_hm_egy[nrow(h_hm_egy) + 30,] <- NA
    forecast_hm_egy$r_orders <- h_hm_egy$y
    forecast_hm_egy$brand_country <- "hm_egy"


    #####
    #### Hourly forecast_hm_ksa
    ###


    start_date <- Sys.Date() - 8
    end_date <- Sys.Date()

    ga_id <- "ga:164870155"
    h_hm_ksa <- google_analytics(ga_id,
                                 date_range = c(start_date, end_date),
                                 metrics = c("sessions", "transactions", "transactionsPerSession"),
                                 dimensions = "dateHour")


    colnames(h_hm_ksa) <- c("ds", "sessions", "y", "cvr")


    ### Regex transform date

    x <- h_hm_ksa$ds
    y <- sub("\\s+$", "", gsub('(.{8})', '\\1 ', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(^.{4})', '\\1-', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(.{7})', '\\1-', x))

    y1 <- y

    x <- y1
    y <- sub("\\s+$", "", gsub('(.{13})', '\\1:00:00', x))

    h_hm_ksa$ds <- y


    ### start modeling
    m <- prophet(h_hm_ksa, growth = "linear", changepoint.range = 0.5,
                 yearly.seasonality = "TRUE", weekly.seasonality = "TRUE",
                 daily.seasonality = "TRUE", holidays = NULL,
                 seasonality.mode = "multiplicative", seasonality.prior.scale = 50,
                 holidays.prior.scale = 10, changepoint.prior.scale = 0.2,
                 mcmc.samples = 0, interval.width = 0.8, uncertainty.samples = 1000,
                 fit = TRUE)


    future <- make_future_dataframe(m, periods = 30, freq = 60 * 60)
    forecast_hm_ksa <- predict(m, future)
    tail(forecast_hm_ksa[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_hm_ksa[nrow(h_hm_ksa) + 30,] <- NA
    forecast_hm_ksa$r_orders <- h_hm_ksa$y
    forecast_hm_ksa$brand_country <- "hm_ksa"


    #####
    #### Hourly forecast_mc_uae
    ###


    start_date <- Sys.Date() - 8
    end_date <- Sys.Date()

    ga_id <- "ga:114955062"
    h_mc_uae <- google_analytics(ga_id,
                                 date_range = c(start_date, end_date),
                                 metrics = c("sessions", "transactions", "transactionsPerSession"),
                                 dimensions = "dateHour")


    colnames(h_mc_uae) <- c("ds", "sessions", "y", "cvr")


    ### Regex transform date

    x <- h_mc_uae$ds
    y <- sub("\\s+$", "", gsub('(.{8})', '\\1 ', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(^.{4})', '\\1-', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(.{7})', '\\1-', x))

    y1 <- y

    x <- y1
    y <- sub("\\s+$", "", gsub('(.{13})', '\\1:00:00', x))

    h_mc_uae$ds <- y


    ### start modeling
    m <- prophet(h_mc_uae, growth = "linear", changepoint.range = 0.5,
                 yearly.seasonality = "TRUE", weekly.seasonality = "TRUE",
                 daily.seasonality = "TRUE", holidays = NULL,
                 seasonality.mode = "multiplicative", seasonality.prior.scale = 50,
                 holidays.prior.scale = 10, changepoint.prior.scale = 0.2,
                 mcmc.samples = 0, interval.width = 0.8, uncertainty.samples = 1000,
                 fit = TRUE)


    future <- make_future_dataframe(m, periods = 30, freq = 60 * 60)
    forecast_mc_uae <- predict(m, future)
    tail(forecast_mc_uae[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_mc_uae[nrow(h_mc_uae) + 30,] <- NA
    forecast_mc_uae$r_orders <- h_mc_uae$y
    forecast_mc_uae$brand_country <- "mc_uae"


    #####
    #### Hourly forecast_mc_ksa
    ###


    start_date <- Sys.Date() - 8
    end_date <- Sys.Date()

    ga_id <- "ga:114976409"
    h_mc_ksa <- google_analytics(ga_id,
                                 date_range = c(start_date, end_date),
                                 metrics = c("sessions", "transactions", "transactionsPerSession"),
                                 dimensions = "dateHour")


    colnames(h_mc_ksa) <- c("ds", "sessions", "y", "cvr")


    ### Regex transform date

    x <- h_mc_ksa$ds
    y <- sub("\\s+$", "", gsub('(.{8})', '\\1 ', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(^.{4})', '\\1-', x))

    y

    x <- y
    y <- sub("\\s+$", "", gsub('(.{7})', '\\1-', x))

    y1 <- y

    x <- y1
    y <- sub("\\s+$", "", gsub('(.{13})', '\\1:00:00', x))

    h_mc_ksa$ds <- y


    ### start modeling
    m <- prophet(h_mc_ksa, growth = "linear", changepoint.range = 0.5,
                 yearly.seasonality = "TRUE", weekly.seasonality = "TRUE",
                 daily.seasonality = "TRUE", holidays = NULL,
                 seasonality.mode = "multiplicative", seasonality.prior.scale = 50,
                 holidays.prior.scale = 10, changepoint.prior.scale = 0.2,
                 mcmc.samples = 0, interval.width = 0.8, uncertainty.samples = 1000,
                 fit = TRUE)


    future <- make_future_dataframe(m, periods = 30, freq = 60 * 60)
    forecast_mc_ksa <- predict(m, future)
    tail(forecast_mc_ksa[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
    h_mc_ksa[nrow(h_mc_ksa) + 30,] <- NA
    forecast_mc_ksa$r_orders <- h_mc_ksa$y
    forecast_mc_ksa$brand_country <- "mc_ksa"


    ###Join both tables
    inner <- rbind(forecast_bbw_ksa, forecast_bbw_uae, forecast_hm_uae, forecast_hm_egy, forecast_hm_ksa, forecast_mc_uae, forecast_mc_ksa)
    write.csv(inner, file = "f_bbw.csv")
    print("Fetching hourly forcast by prophet is done..")
}