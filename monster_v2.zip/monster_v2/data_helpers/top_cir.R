library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)


get_top_cir <- function(){
    print("Fetching Top CIR Data..")

    end_date <- Sys.Date() - 1

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SUM(gross_revenue)/SUM(orders) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.33)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    (SUM(affiliate_cost) + SUM(cost)) / sum(orders) as CPO,
    (SUM(affiliate_cost) + SUM(cost)) / sum(new_customers) as CPA,
    (SUM(affiliate_cost) + SUM(cost)) / sum(gross_revenue) as CIR,
    (SUM(affiliate_cost) + SUM(cost)) / SUM(session) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'HM_EGY' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_hm_egy_p <- bq_table_download(offence_qtr)

    df_hm_egy_p <- df_hm_egy_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### HM UAE


    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SUM(gross_revenue)/SUM(orders) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.33)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    (SUM(affiliate_cost) + SUM(cost)) / sum(orders) as CPO,
    (SUM(affiliate_cost) + SUM(cost)) / sum(new_customers) as CPA,
    (SUM(affiliate_cost) + SUM(cost)) / sum(gross_revenue) as CIR,
    (SUM(affiliate_cost) + SUM(cost)) / SUM(session) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'HM_UAE' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_hm_uae_p <- bq_table_download(offence_qtr)

    df_hm_uae_p <- df_hm_uae_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### HM KSA


    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SUM(gross_revenue)/SUM(orders) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.33)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    (SUM(affiliate_cost) + SUM(cost)) / sum(orders) as CPO,
    (SUM(affiliate_cost) + SUM(cost)) / sum(new_customers) as CPA,
    (SUM(affiliate_cost) + SUM(cost)) / sum(gross_revenue) as CIR,
    (SUM(affiliate_cost) + SUM(cost)) / SUM(session) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'HM_KSA' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_hm_ksa_p <- bq_table_download(offence_qtr)

    df_hm_ksa_p <- df_hm_ksa_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### BBW UAE


    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SUM(gross_revenue)/SUM(orders) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.31)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    (SUM(affiliate_cost) + SUM(cost)) / sum(orders) as CPO,
    (SUM(affiliate_cost) + SUM(cost)) / sum(new_customers) as CPA,
    (SUM(affiliate_cost) + SUM(cost)) / sum(gross_revenue) as CIR,
    (SUM(affiliate_cost) + SUM(cost)) / SUM(session) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'BB_UAE' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_bbw_uae_p <- bq_table_download(offence_qtr)

    df_bbw_uae_p <- df_bbw_uae_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### BBW UAE


    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SUM(gross_revenue)/SUM(orders) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.31)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    (SUM(affiliate_cost) + SUM(cost)) / sum(orders) as CPO,
    (SUM(affiliate_cost) + SUM(cost)) / sum(new_customers) as CPA,
    (SUM(affiliate_cost) + SUM(cost)) / sum(gross_revenue) as CIR,
    (SUM(affiliate_cost) + SUM(cost)) / SUM(session) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'BB_UAE' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_bbw_ksa_p <- bq_table_download(offence_qtr)


    df_bbw_ksa_p <- df_bbw_ksa_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### MC KSA


    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.31)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SAFE_DIVIDE(SUM(orders), SUM(session)) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'MC_KSA' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_mc_ksa_p <- bq_table_download(offence_qtr)


    df_mc_ksa_p <- df_mc_ksa_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### bbw_ksa

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.31)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SAFE_DIVIDE(SUM(orders), SUM(session)) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'BB_KSA' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_bbw_ksa_p <- bq_table_download(offence_qtr)

    df_bbw_ksa_p <- df_bbw_ksa_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### vs_ksa

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.31)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'VS_KSA' and date between '2020-06-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_vs_ksa_p <- bq_table_download(offence_qtr)

    df_vs_ksa_p <- df_vs_ksa_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### vs_uae

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.31)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SAFE_DIVIDE(SUM(orders), SUM(session)) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'VS_UAE' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_vs_uae_p <- bq_table_download(offence_qtr)

    df_vs_uae_p <- df_vs_uae_p %>%
        filter(rank(desc(brand_ctb)) <= 60)


    #### AEO UAE


    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.31)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SAFE_DIVIDE(SUM(orders), SUM(session)) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'AO_UAE' and date between '2020-06-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_AEO_UAE_p <- bq_table_download(offence_qtr)

    df_AEO_UAE_p <- df_AEO_UAE_p %>%
        filter(rank(desc(brand_ctb)) <= 10)


    #### AEO KSA

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.31)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SAFE_DIVIDE(SUM(orders), SUM(session)) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'AO_KSA' and date between '2020-06-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_AO_KSA_p <- bq_table_download(offence_qtr)

    df_AO_KSA_p <- df_AO_KSA_p %>%
        filter(rank(desc(brand_ctb)) <= 10)


    #### AEO EGY

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SUM(gross_revenue)/SUM(orders) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.33)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    (SUM(affiliate_cost) + SUM(cost)) / sum(orders) as CPO,
    (SUM(affiliate_cost) + SUM(cost)) / sum(new_customers) as CPA,
    (SUM(affiliate_cost) + SUM(cost)) / sum(gross_revenue) as CIR,
    (SUM(affiliate_cost) + SUM(cost)) / SUM(session) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'AO_EGY' and date between '2020-06-15' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_AO_EGY_p <- bq_table_download(offence_qtr)

    df_AO_EGY_p <- df_AO_EGY_p %>%
        filter(rank(desc(brand_ctb)) <= 10)

    #### fl_ksa

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.19)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'FL_KSA' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_fl_ksa_p <- bq_table_download(offence_qtr)

    df_fl_ksa_p <- df_fl_ksa_p %>%
        filter(rank(desc(brand_ctb)) <= 30)


    #### fl_uae

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.19)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'FL_UAE' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_fl_uae_p <- bq_table_download(offence_qtr)

    df_fl_uae_p <- df_fl_uae_p %>%
        filter(rank(desc(brand_ctb)) <= 30)


    #### pb_uae

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.37)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'PB_UAE' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_pb_uae_p <- bq_table_download(offence_qtr)

    df_pb_uae_p <- df_pb_uae_p %>%
        filter(rank(desc(brand_ctb)) <= 30)


    #### pb_ksa

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.37)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'PB_KSA' and date between '2020-01-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_pb_ksa_p <- bq_table_download(offence_qtr)

    df_pb_ksa_p <- df_pb_ksa_p %>%
        filter(rank(desc(brand_ctb)) <= 30)


    #### WE KSA

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.37)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'WE_KSA' and date between '2020-05-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_wes_ksa_p <- bq_table_download(offence_qtr)

    df_wes_ksa_p <- df_wes_ksa_p %>%
        filter(rank(desc(brand_ctb)) <= 10)


    #### we_uae

    sql_query <- sprintf("SELECT
    date,
    brand_country,
    SUM(orders) as orders,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(SUM(gross_revenue), SUM(orders)) as AOV,
    SUM(gross_revenue) as gross_revenue,
    (SUM(gross_revenue)*0.37)-(SUM(affiliate_cost) + SUM(cost)) as brand_ctb,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SUM(orders)/SUM(session) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where brand_country = 'WE_UAE' and date between '2020-05-01' and '%s'

    group by
    1,2

    order by 1 asc", end_date)

    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_wes_uae_p <- bq_table_download(offence_qtr)

    df_wes_uae_p <- df_wes_uae_p %>%
        filter(rank(desc(brand_ctb)) <= 10)


    cir_top <- rbind(df_bbw_ksa_p, df_bbw_uae_p, df_hm_egy_p, df_hm_ksa_p, df_hm_uae_p,
                     df_mc_ksa_p, df_bbw_ksa_p, df_vs_ksa_p, df_vs_uae_p,
                     df_AEO_UAE_p, df_AO_KSA_p, df_AO_EGY_p, df_fl_ksa_p,
                     df_fl_uae_p, df_pb_uae_p, df_pb_ksa_p, df_wes_ksa_p, df_wes_uae_p)

    write.csv(cir_top, file = "cir_top.csv")
    print("Fetching Top CIR Data is Done..")
}