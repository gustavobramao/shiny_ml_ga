library(bigrquery)
library(bigQueryR)
library(googleAuthR)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(googleAnalyticsR)
library(gtrendsR)

get_outlier_cir <- function(){
    print("Fetching Outlier CIR Data..")

    start_date <- Sys.Date() - 8
    end_date <- Sys.Date() - 2


    # BigQuery Auth
    bq_conn <- get_bq_conn()
    bigrquery::dbListTables(bq_conn)

    #### last week.

    sql_query <- sprintf("SELECT
    brand,
    SUM(orders) as orders,
    SUM(gross_revenue) as gross_revenue,
    SAFE_DIVIDE(sum(new_customers),sum(orders)) as new_customers,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(sum(gross_revenue), SUM(orders)) AS AOV,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SAFE_DIVIDE(SUM(orders), SUM(session)) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where date between '%s' and '%s'

    group by
    1


    order by 1 asc", start_date, end_date)


    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_cpo <- bq_table_download(offence_qtr)


    start_date <- Sys.Date() - 1
    end_date <- Sys.Date() - 1

    #### Yesterday

    sql_query <- sprintf("SELECT
    brand,
    SUM(orders) as orders,
    SUM(gross_revenue) as gross_revenue,
    SAFE_DIVIDE(sum(new_customers),sum(orders)) as new_customers,
    (SUM(affiliate_cost) + SUM(cost)) as total_cost,
    SUM(session) as sessions,
    SAFE_DIVIDE(sum(gross_revenue), SUM(orders)) AS AOV,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(orders)) as CPO,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(new_customers)) as CPA,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), sum(gross_revenue)) as CIR,
    SAFE_DIVIDE((SUM(affiliate_cost) + SUM(cost)), SUM(session)) as CPV,
    SAFE_DIVIDE(SUM(orders), SUM(session)) as CvR

    FROM `authentic-codex-225113.monaliza_bi.daily_cost_session_orders`
    where date between '%s' and '%s'

    group by
    1


    order by 1 asc", start_date, end_date)


    offence_qtr <- bq_project_query('authentic-codex-225113', sql_query)
    df_cpo_yesterday <- bq_table_download(offence_qtr)


    #import promo calendar.
    cir_target <- gsheet2tbl('https://docs.google.com/spreadsheets/d/1Y4JPX09kCdbt6PXxmlyvC1h55TYdc_3ztxopkN0P4pM/edit?usp=sharing')

    df_cpo$target_cir <- 0

    df_cpo$target_cir[1:1] <- 0.15
    df_cpo$target_cir[2:2] <- 0.13
    df_cpo$target_cir[3:3] <- 0.05
    df_cpo$target_cir[4:4] <- 0.16
    df_cpo$target_cir[5:5] <- 0.10
    df_cpo$target_cir[6:6] <- 0.14
    df_cpo$target_cir[7:7] <- 0.15
    df_cpo$target_cir[8:8] <- 0.14

    write.csv(df_cpo, file = "df_cpo.csv")


    df_cpo_yesterday$target_cir <- 0

    df_cpo_yesterday$target_cir[1:1] <- 0.15
    df_cpo_yesterday$target_cir[2:2] <- 0.13
    df_cpo_yesterday$target_cir[3:3] <- 0.05
    df_cpo_yesterday$target_cir[4:4] <- 0.16
    df_cpo_yesterday$target_cir[5:5] <- 0.10
    df_cpo_yesterday$target_cir[6:6] <- 0.14
    df_cpo_yesterday$target_cir[7:7] <- 0.15
    df_cpo_yesterday$target_cir[8:8] <- 0.14


    write.csv(df_cpo_yesterday, file = "df_cpo_yesterday.csv")
    write.csv(cir_target, file = "cir_target.csv")
    print("Fetching Outlier CIR Data is Done..")
}
