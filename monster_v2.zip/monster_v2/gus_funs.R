library(highcharter)
library(broom)
library(rlang)
library(DT)

R2 <- function(fit){
  r2 <- 1 - crossprod(residuals(fit)) / crossprod(fit$model[,1] - mean(fit$model[,1]))
  r2 <- as.numeric(r2)
  return(r2)
}

R2_gen <- function(obs, pred) {
  resid <- obs - pred
  r2 <- 1 - crossprod(resid) / crossprod(obs - mean(obs))
  r2 <- as.numeric(r2)
  return(r2)
}

is_model_lm <- function(x) {
  inherits(x,"lm")
}

tiene_intercept <- function(fit){
  if(is_model_lm(fit)){
    return("(Intercept)" %in% (fit %>% tidy %>% .[["term"]]))
  }
  
  if(is_model_shiny(fit)){
    return(fit %>% .[[5]])
  }
  
  if(is_model_coeff(fit)){
    return(fit %>% filter(term == "(Intercept)") %>% nrow %>% as.logical)
  }
}

variable_objetivo <- function(fit) {
  
  if(is_model_lm(fit)){
    return(fit %>% 
             augment %>% 
             select(-one_of(".rownames")) %>%  
             names %>% .[[1]])
  }
  
  if(is_model_coeff(fit)){
    return(fit %>% pull(target_variable) %>% unique)
  }
  
  if(is_model_shiny(fit)){
    return(fit %>% .[[3]])
  }
}

mutate_str <- function(df, strings){
  strings_exp <- strings %>% map(parse_expr)
  eval_tidy(quo(df %>% mutate(!!!strings_exp)))
}

aportes <- function(fit, var_fecha = NULL,base = NULL, alargar = F, 
                    regex_alargar = "", datos_alargar = NULL, 
                    fecha_alargar = "", agrupacion = NULL ) {
  
  if(inherits(fit,"lm")){
    tidy_fit <- tidy(fit)
    output <- augment(fit)
    var_obj <- variable_objetivo(fit)
    
    if (tiene_intercept(fit)){
      output <- output %>% mutate(`(Intercept)` = 1)
    }
    
    output <- output %>%
      tbl_df %>%
      select(-matches("^\\.")) %>%
      select(-one_of(variable_objetivo(fit)))
  }
  
  if(inherits(fit,"data.frame") & ("term" %in% names(fit)) & 
     ("estimate" %in% names(fit))){
    if(is.null(base)) 
      stop("Si fit es un data.frame, es necesario informar la base")
    tidy_fit <- fit
    output <- base
    if("(Intercept)" %in% (tidy_fit %>% pull(term))){
      output <- output %>% mutate(`(Intercept)` = 1)
    }
    output <- output %>% select(one_of(tidy_fit %>% pull(term)))
  }
  
  if(inherits(fit,"data.frame") & !("term" %in% names(fit)) & 
     !("estimate" %in% names(fit))){
    nombre_fecha <- fit %>% names %>% .[[1]] %>% sym
    fit <- fit %>% rename(fecha = !!nombre_fecha)
    return(fit)
  }
  
  if (!is.null(base) & is.character(var_fecha) ) {
    if(var_fecha %in% names(base)) {
      var_fecha <- base[, var_fecha]
    }
  }
  
  if(is.null(var_fecha)){
    var_fecha <- as.Date.numeric(1:nrow(output), origin = "2017-01-01")
  }
  
  output <- output %>%
    mutate(fecha = var_fecha)
  
  orden <- names(output)
  
  if(alargar){
    if(is.null(datos_alargar)){
      stop("Para alargar los aportes, proporciona un dataframe en datos_alargar")
    }
    if(fecha_alargar == ""){
      warning("Considerando la primera columna de datos_alargar como fecha principal")
      fecha_alargar <- names(datos_alargar) %>% .[[1]]
    }
    
    output <- datos_alargar %>%
      select(one_of(fecha_alargar),one_of(tidy_fit %>% .[["term"]])) %>%
     select(matches(paste0("^",fecha_alargar,"$|",regex_alargar))) %>%
      rename_("fecha" = fecha_alargar) %>%
      filter(fecha >= var_fecha[1]) %>%
      left_join(output %>%
                  select(-matches(regex_alargar)) ,
                by ="fecha")
    
    
  }
  
  nombres <- tidy_fit%>% pull(term) %>% map(sym)
  estimates <- tidy_fit %>% pull(estimate)
  formulas <-paste0(nombres, " := ", nombres," * ",estimates)
  
  output <- output %>%
    mutate_str(formulas)
  
  if(!is.null(agrupacion)){
    
    orden <- agrupacion %>% pull(grupo_variable) %>% unique
    
    verificacion <- output %>%
      select(-fecha) %>%
      summarise_all(sum) %>%
      gather("variable","aporte") %>%
      left_join(agrupacion)
    
    variables_sin_grupo <- verificacion %>%
      filter(is.na(grupo_variable)) %>% pull(variable)
    
    if(length(variables_sin_grupo) != 0){
      stop(paste0("Las variables ",
                  str_c(variables_sin_grupo, collapse=", "),
                  " no están asociadas a ningún grupo"))
    }
    
    formulas <- agrupacion %>%
      mutate_all(funs(map(.,sym) %>% as.character)) %>%
      group_by(grupo_variable) %>%
      summarise(variable = str_c(variable, collapse = " + ")) %>%
      mutate(formula = paste0(grupo_variable, " := ", variable)) %>%
      pull(formula)
    
    
    output <- output %>%
      mutate_str(formulas) %>%
      select(fecha, one_of(agrupacion %>% pull(grupo_variable)))
  }
  
  output <- output %>%
    select(fecha,one_of(orden))
  
  output
}

dibuja_ajuste <- function(fit, variable_fechas = NULL, nombre_variable_objetivo, 
                          base = NULL, interactivo = TRUE) {
  
  if(inherits(fit,"lm")){
    augment_fit <- augment(fit)
    var_obj <- variable_objetivo(fit)
  }
  
  if(inherits(fit,"data.frame")){
    if(is.null(base)) 
      stop("Si fit es un data.frame, es necesario informar la base")
    augment_fit <- base
    var_obj <- nombre_variable_objetivo
  }
  
  #Validaciones
  if(!(var_obj %in% names(augment_fit))) 
    stop(paste0(var_obj, " no se encuentra en los datos"))
  var_obj <- augment_fit %>% pull(var_obj)
  
  aportes <- aportes(fit,variable_fechas,base)
  fecha <- aportes %>% pull(1)
  ajuste <- aportes %>% select(-1) %>% rowSums()
  
  aux <- data_frame(fecha = fecha,
                    Original= var_obj,
                    Ajuste = ajuste)
  
  if(interactivo){
    
    highchart() %>%
      hc_title(text = "Ajuste del modelo",useHTML=TRUE) %>%
      hc_chart(style=list(fontFamily="Trebuchet MS"), zoomType = "xy") %>%
      hc_legend(enabled = TRUE) %>%
      hc_xAxis(categories = format(aux$fecha,format="%d/%m/%Y"),
               labels=list(rotation=-90)) %>%
      hc_yAxis( title = list(text = nombre_variable_objetivo,useHTML=TRUE),
                align = "right",
                showFirstLabel = FALSE,
                showLastLabel = FALSE,
                labels = list(format = "{value}", useHTML = TRUE),
                gridLineWidth= 0,
                allowDecimals=FALSE,
                reversed=FALSE,
                endOnTick = FALSE
      ) %>%
      hc_tooltip(useHTML = TRUE,
                 valueDecimals = ifelse(max(aux$Original) < 1, 
                                        2, 
                                        ifelse(max(aux$Original) < 10,1,0))) %>%
      hc_add_series(name = "Original", type = "spline",
                    data = aux$Original,
                    cursor = "pointer",
                    color = "blue",
                    lineWidth = 2,
                    marker = list(enabled = FALSE)) %>%
      hc_add_series(name = "Ajuste", type="spline",
                    data=aux$Ajuste,
                    cursor="pointer",
                    color="red",
                    lineWidth=2,
                    marker = list(enabled = FALSE)) -> P
    
  } else {
    
    P <- ggplot(melt(aux,id.vars="fecha"),
                aes(x=fecha,y=value,group=variable,col=variable))+
      geom_line(size=1.5)+
      theme_bw()+
      labs(x = "", y = nombre_variable_objetivo)+
      theme(legend.position="bottom",legend.title=element_blank(),
            axis.text.x = element_text(angle = 90, size = 8),
            panel.grid.major = element_line(colour = NA),
            panel.grid.minor = element_line(colour = NA))+
      scale_color_manual(values=c("darkblue","red"))+
      scale_x_date(breaks= date_breaks("2 weeks"))
    
  }
  
  return(P)
  
}

tabla_coeficientes <- function(base_aux,model,confidence = 0.95) {
  
  tabla <- data.frame(cbind(summary(model)$coefficients[,1],
                            confint(model,level=confidence),
                            summary(model)$coefficients[,4]))
  colnames(tabla) <- c("estimate",paste("Lim. inf. IC",
                                        round(confidence*100),"%"),
                       paste("Lim. sup. IC",round(confidence*100),"%"),
                       "p-valores")
  tabla <- tabla %>% rownames_to_column("term")
  tabla$elasticidad <- NA
  if(tiene_intercept(model)){
    for(i in 2:nrow(tabla)){
      var <- tabla %>% slice(i) %>% pull(term)
      tabla$elasticidad[i] <- 
        tabla$estimate[i]*mean(base_aux[,var])/mean(model$fitted.values)/100
    }
  }else{
    for(i in 1:nrow(tabla)){
      var <- tabla %>% slice(i) %>% pull(term)
      tabla$elasticidad[i] <- 
        tabla$estimate[i]*mean(base_aux %>% 
                                 pull(var))/mean(model$fitted.values)/100
    }
  }
  return(tabla)
  
}

datatable_coeficientes <-   function(tabla) {
  tabla <- tabla %>% column_to_rownames("term")
  
  if(tabla %>% 
     summarise(sum(elasticidad, na.rm=T)) %>% 
     pull %>% near(1,tol = 0.1)) {
    tabla$elasticidad <- tabla$elasticidad/100
  }
  
  datatable(tabla, options = list(pageLength = 50, autoWidth = TRUE)) %>%
    formatPercentage(5,digits=2) %>%
    formatRound(1:4,digits=3) %>% formatStyle(
      1:3,
      color =  'white',
      backgroundColor = styleInterval(0,c('red','green'))
    ) %>% formatStyle(
      4,
      color =  'black',
      backgroundColor = styleInterval(c(0.05,0.1),
                                      c('lightgreen','yellow','grey'))
    )
}

max_min_scale <- function(tb_data, ...) {
  expr_vars <- c(...)
  
  print(expr_vars)
  print(length(expr_vars))
  l_params <- vector(mode = "list", length = length(expr_vars))
  
  for(i in seq_along(l_params)) {
    orig_nums <- tb_data %>% pull(expr_vars[[i]])
    m   <- min(orig_nums)
    M_m <- max(orig_nums) - m
    l_params[[i]] <- c(m = m, M_m = M_m)
    
    q_n <- expr_vars[[i]]
    tb_data <- tb_data %>% 
      mutate(!!q_n := (orig_nums - m) / M_m)
  }
  
  out <- list(tb_data = tb_data, scale_params = l_params)
  names(out$scale_params) <- lapply(expr_vars, function(x) x
  )
  
  out[["scale_params"]] <- out[["scale_params"]] %>% 
    as.data.frame() %>% 
    as.matrix()
  
  return(out)
}


bsts_coefs <- function(m_bsts) {
  tb_coefs <- m_bsts$coefficients %>% colMeans() %>% 
    as.data.frame %>% 
    rownames_to_column(var = "Var") %>% 
    left_join(
      m_bsts$coefficients %>% 
        apply(2, quantile) %>% 
        as.data.frame %>% 
        rownames_to_column(var = "quart") %>% 
        gather(Var, Val, -quart) %>% 
        spread(quart, Val), by = "Var") 
  
  names(tb_coefs)[2] <- "Mean"
  tb_coefs <- tb_coefs %>% 
    transmute(Var = Var, Mean = Mean,
              `0%` = `0%`, `25%` = `25%`, `50%` = `50%`, 
              `75%` = `75%`, `100%` = `100%`)  %>% slice(-1) %>% 
    arrange(Var)
  tb_coefs
}

bayesian_coefs <- function(fit, res_max_min_scale, names_betas, sgn_betas) {
  
  # names_betas <- names(sgn_betas)
  
  tb_coefs <- sapply(names_betas, function(x) {
    rstan::extract(fit, x)[[1]] %>% mean
  }) %>% 
    as.data.frame %>% 
    rownames_to_column(var = "Var") %>% 
    left_join(
      sapply(names_betas, function(x) {
        rstan::extract(fit, x)[[1]] %>% quantile()
      }) %>% 
        apply(2, quantile) %>% 
        as.data.frame %>% 
        rownames_to_column(var = "quart") %>% 
        gather(Var, Val, -quart) %>% 
        spread(quart, Val), by = "Var")
  
  names(tb_coefs)[2] <- "Mean"
  tb_coefs <- tb_coefs %>% 
    transmute(Var = Var, Mean = Mean,
              `0%` = `0%`, `25%` = `25%`, `50%` = `50%`, 
              `75%` = `75%`, `100%` = `100%`)
  
  tb_coefs <- apply(tb_coefs, 1, function(x) {
    v <- str_remove(x[1], "b_")
    M_m_i <- res_max_min_scale$scale_params["M_m", v]
    x[-1] <- M_m_y / M_m_i * as.numeric(x[-1])
    
    return(x)
  }) %>% t %>% as.data.frame() %>% 
    mutate_at(vars(Mean:`100%`), function(x) as.numeric(as.character(x))) %>% 
    mutate(Var = as.character(Var))
  
  tb_coefs <- tb_coefs %>% 
    mutate_at(vars(Mean:`100%`), 
              function(x) x * sgn_betas[(tb_coefs %>% pull(Var))]) %>% 
    mutate(Var = str_remove(Var, "b_")) %>% 
    arrange(Var)
  
  tb_coefs
}