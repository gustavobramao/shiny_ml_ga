library(dplyr)
library(prophet)
library(bigrquery)
library(bigQueryR)
library(googleAuthR)
library(gsheet)
library(config)

options(googleAuthR.scopes.selected = c(
  "https://www.googleapis.com/auth/bigquery",
  "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(knitr)
library(googleAnalyticsR)
library(gtrendsR)

if (config::is_active("production")) {
  print("Environment is production")
  setwd('/var/www/shiny_app')
}

if (config::is_active("default")) {
  print("Environment is default")
}

source("helpers.R")

gar_auth_service("conn.json")
knitr::opts_chunk$set(echo = TRUE)

source("~/Documents/R Scripts/monster_v2/data_helpers/get_monalisa_macro_bands.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/get_query_products_n_days.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/last_week_ga_compare.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/hourly_forecast.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/ga_sessions_transactions.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/daily_forecast.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/user_funnel.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/products_performance.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/outlier_cir.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/top_cir.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/paid_unpaid_gtrends.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/ga_data_helpers.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/channel_grouping.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/gtrends_data.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/monaliza_new_gus.R")



start_date <- Sys.Date() - 10
end_date <- Sys.Date() - 1
metrics <- c("sessions", "bounceRate", "transactionsPerSession", "transactions")
dimensions <- "landingPagePath"
columns <- c("landingPagePath", "sessions", "bounceRate", "transactionsPerSession", "transactions", "brand_country")

get_ga_data(start_date = start_date, end_date = end_date, metrics = metrics,
            dimensions = dimensions, file_name = "page1_perf.csv", columns = columns)


we <- read.csv("page1_perf.csv")


new <- we %>% filter(sessions>50&transactionsPerSession>0.5) 
