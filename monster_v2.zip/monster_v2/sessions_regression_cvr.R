library(dplyr)
library(prophet)
library(bigrquery)
library(bigQueryR)
library(googleAuthR)
library(gsheet)
library(config)

options(googleAuthR.scopes.selected = c(
  "https://www.googleapis.com/auth/bigquery",
  "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(knitr)
library(googleAnalyticsR)
library(gtrendsR)

if (config::is_active("production")) {
  print("Environment is production")
  setwd('/var/www/shiny_app')
}

if (config::is_active("default")) {
  print("Environment is default")
}

source("helpers.R")

gar_auth_service("conn.json")
knitr::opts_chunk$set(echo = TRUE)

source("~/Documents/R Scripts/monster_v2/data_helpers/get_monalisa_macro_bands.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/get_query_products_n_days.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/last_week_ga_compare.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/hourly_forecast.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/ga_sessions_transactions.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/daily_forecast.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/user_funnel.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/products_performance.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/outlier_cir.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/top_cir.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/paid_unpaid_gtrends.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/ga_data_helpers.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/channel_grouping.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/gtrends_data.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/monaliza_new_gus.R")

start_time <- Sys.time()
df_all <- monaliza_new_gus()

###
### Cluster 
###

bbw <- macro2 %>% filter(brand_country=="BB_KSA" & date <"2020-03-01") %>% select(session, cost)
bbw <- bbw[1:2]

# Sample data
rData <- bbw[1:2]
print(rData)


# Cluster
d <- dist(scale(rData), method="euclidean", diag=TRUE, upper=TRUE)
hls <- hclust(d, method="complete")

# Create groups
cluster <- cutree(hls, 3)

# Create scatter plot
ggData <- cbind(rData, cluster)
ggData$cluster <- as.factor(ggData$cluster)
print(ggData)
ggplot(ggData, aes(x=session, y=cost, color=cluster)) + geom_point(size=3)



library(plotly)

fig <- plot_ly(data = ggData, x = ~session, y = ~cost, name ="clusters", color = ~cluster)
fig

#### Time serie cost
#### Plot costs.

bbw1 <- df_all %>% filter(brand=="bbw")

fig <- plot_ly(bbw1) 
fig <- fig %>% add_trace(x =~date, y = ~affiliate_cost, name = 'afflilate cost', type= 'scatter', mode = "line") 
fig <- fig %>% add_trace(x =~date, y = ~sms_costs, name = 'sms cost', type= 'scatter', mode = "line") 
fig <- fig %>% add_trace(x =~date, y = ~facebook_costs, name = 'facebook cost', type= 'scatter', mode = "line") 
fig <- fig %>% add_trace(x =~date, y = ~criteo_costs, name = 'criteo cost', type= 'scatter', mode = "line")
fig <- fig %>% add_trace(x =~date, y = ~partnerize_costs, name = 'Partnerize cost', type= 'scatter', mode = "line")

fig
