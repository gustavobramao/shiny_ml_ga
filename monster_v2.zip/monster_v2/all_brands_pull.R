library(dplyr)
library(prophet)
library(bigrquery)
library(bigQueryR)
library(googleAuthR)
library(gsheet)
library(config)

options(googleAuthR.scopes.selected = c(
    "https://www.googleapis.com/auth/bigquery",
    "https://www.googleapis.com/auth/analytics")
)

library(RGoogleAnalytics)
library(knitr)
library(googleAnalyticsR)
library(gtrendsR)

if (config::is_active("production")) {
    print("Environment is production")
    setwd('/var/www/shiny_app')
}

if (config::is_active("default")) {
    print("Environment is default")
}

source("helpers.R")

gar_auth_service("conn.json")
knitr::opts_chunk$set(echo = TRUE)

source("~/Documents/R Scripts/monster_v2/data_helpers/get_monalisa_macro_bands.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/get_query_products_n_days.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/last_week_ga_compare.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/hourly_forecast.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/ga_sessions_transactions.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/daily_forecast.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/user_funnel.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/products_performance.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/outlier_cir.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/top_cir.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/paid_unpaid_gtrends.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/ga_data_helpers.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/channel_grouping.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/gtrends_data.R")
source("~/Documents/R Scripts/monster_v2/data_helpers/monaliza_new_gus.R")

start_time <- Sys.time()


get_monalisa_macro_bands()
get_query_products_n_days_before()
get_last_week_ga_compare()
get_hourly_forecast()
get_ga_sessions_transactions()
get_daily_forecast() # dependent on get_monalisa_macro_bands
get_user_funnel_data()
get_products_performance()
get_outlier_cir()
get_top_cir()
get_paid_unpaid_gtrends()
get_channel_grouping()
get_ga_sessions_transaction()
get_gtrends_data() # dependent on get_paid_unpaid_gtrends
get_ml_models_data()
get_weekly_brand_data()
monaliza_new_gus()


total_time <- difftime(Sys.time(), start_time, units="mins")

sprintf("Total Duration for Execution: %s minutes", total_time)
print("All Brands Cron Execution is Done..")
