library(shiny)
library(plotly)
require(shinydashboard)
library(dplyr)
library(DT)
library(config)

if (config::is_active("production")){
  setwd('/var/www/shiny_app')
}

#import data set
df_all <- read.csv("df_all.csv", stringsAsFactors = F, header = T)
macro <- read.csv("macro_brands.csv", stringsAsFactors = F, header = T)

#import data set
df_bbw_products <- read.csv("df_bbw_products.csv", stringsAsFactors = F, header = T)
df_bbw_products_14 <- read.csv("df_bbw_products_14.csv", stringsAsFactors = F, header = T)

#import data set
bbw_ksa_cvr <- read.csv("bbw_ksa_cvr.csv", stringsAsFactors = F, header = T)
bbw_uae_cvr <- read.csv("bbw_uae_cvr.csv", stringsAsFactors = F, header = T)
forecast <- read.csv("f_bbw.csv", stringsAsFactors = F, header = T)
inner_ga <- read.csv("iga.csv", stringsAsFactors = F, header = T)
inner_forecast <- read.csv("inner_forecast.csv", stringsAsFactors = F, header = T)
df1 <- read.csv("df1.csv", stringsAsFactors = F, header = T)
funnel_historical <- read.csv("funnel_historical.csv", stringsAsFactors = F, header = T)
funnel7 <- read.csv("funnel7.csv", stringsAsFactors = F, header = T)
funnelt <- read.csv("funnelt.csv", stringsAsFactors = F, header = T)


#import product PLPs
bbw_ksa_product <- read.csv("pr2.csv", stringsAsFactors = F, header = T)
bbw_ksa_product_60 <- read.csv("bb2.csv", stringsAsFactors = F, header = T)


### import more DF

df_cpo <- read.csv("df_cpo.csv", stringsAsFactors = F, header = T)
df_cpo_yesterday <- read.csv("df_cpo_yesterday.csv", stringsAsFactors = F, header = T)
cir_target <- read.csv("cir_target.csv", stringsAsFactors = F, header = T)


#Dashboard header carrying the title of the dashboard
header <- dashboardHeader(title = "Monster Dashboard")

#Sidebar content of the dashboard
sidebar <- dashboardSidebar(
  sidebarMenu(
    menuItem("Macro", tabName = "macro", icon = icon("dashboard")),
    menuItem("Dashboard", tabName = "dashboard", icon = icon("globe")),
    menuItem("Paid", tabName = "paid", icon = icon("usd")),
    menuItem("EDA", tabName = "eda", icon = icon("usd")),
    menuItem("Products", tabName = "products", icon = icon("wrench")),
    menuItem("products_ga", tabName = "products_ga", icon = icon("wrench")),
    menuItem("Forecast Per Day", tabName = "per_day", icon = icon("road")),
    menuItem("forecast Per hour", tabName = "forecast", icon = icon("road")),
    menuItem("ga_data", tabName = "ga_data", icon = icon("signal")),
    menuItem("funnel", tabName = "funnel", icon = icon("signal")),
    menuItem("outliers", tabName = "outliers", icon = icon("search")),
    menuItem("geeky", tabName = "simulator", icon = icon("headphones")),
    menuItem("performance marketing", tabName = "", icon = icon("heart"))
  )
)


body <- dashboardBody(


## 3.1 Dashboard body --------------
tabItems(


## 3.0 Time Series ----------------------------------------------------------
tabItem(tabName = 'macro',
        ## contents for the dashboard tab

        fluidPage(
          selectizeInput(
            inputId = "brand",
            label = "brand",
            choices = unique(df_all$brand),
            selected = "bbw",
            multiple = TRUE
          ),


          plotlyOutput(outputId = "m"),
          plotlyOutput(outputId = "m1"),
          plotlyOutput(outputId = "m2"),
          plotlyOutput(outputId = "m3"),
          plotlyOutput(outputId = "m4"),
          plotlyOutput(outputId = "m5"),
          plotlyOutput(outputId = "m6")
        )),


## 3.1 Time Series ----------------------------------------------------------
tabItem(tabName = 'dashboard',
        ## contents for the dashboard tab

        fluidPage(
          selectizeInput(
            inputId = "brand_country",
            label = "Select a brand and country",
            choices = unique(df_all$brand_country),
            selected = "BB_UAE",
            multiple = TRUE
          ),


          plotlyOutput(outputId = "p"),
          plotlyOutput(outputId = "p1"),
          plotlyOutput(outputId = "p2"),
          plotlyOutput(outputId = "p3"),
          plotlyOutput(outputId = "p4"),
          plotlyOutput(outputId = "p5")


        )),


## 3.2 Paid Performance ----------------------------------------------------------
tabItem(tabName = 'paid',
        ## contents for the dashboard tab

        fluidPage(
          selectizeInput(
            inputId = "paid",
            label = "select brand",
            choices = unique(df_all$brand_country),
            selected = "BB_UAE",
            multiple = TRUE
          ),


          plotlyOutput(outputId = "paid1"),
          plotlyOutput(outputId = "paid2"),
          plotlyOutput(outputId = "paid3"),
          plotlyOutput(outputId = "paid4"),
          plotlyOutput(outputId = "paid5"),
          plotlyOutput(outputId = "paid6")
        )),


## 3.3 EDA Performance ----------------------------------------------------------
tabItem(tabName = 'eda',
        ## contents for the dashboard tab

        fluidPage(
          selectizeInput(
            inputId = "eda",
            label = "select brand",
            choices = unique(df_all$brand_country),
            selected = "BB_UAE",
            multiple = TRUE
          ),


          plotlyOutput(outputId = "eda1"),
          plotlyOutput(outputId = "eda2"),
          plotlyOutput(outputId = "eda3")


        )),


## 3.6 Forecast Performance ----------------------------------------------------------
tabItem(tabName = 'per_day',
        ## contents for the dashboard tab

        fluidPage(
          selectizeInput(
            inputId = "per_day",
            label = "select brand",
            choices = unique(inner_forecast$brand_country),
            selected = "bbw_ksa",
            multiple = TRUE
          ),


          plotlyOutput(outputId = "vv3")


        )),


## 3.6 Forecast Performance ----------------------------------------------------------
tabItem(tabName = 'forecast',
        ## contents for the dashboard tab

        fluidPage(
          selectizeInput(
            inputId = "forecast",
            label = "select brand",
            choices = unique(forecast$brand_country),
            selected = "bbw_ksa",
            multiple = TRUE
          ),


          plotlyOutput(outputId = "pp1")


        )),


## 4 Funnel Performance ----------------------------------------------------------
tabItem(tabName = 'funnel',
        ## contents for the dashboard tab

        fluidPage(
          selectizeInput(
            inputId = "funnel_historical",
            label = "select brand funnel historical",
            choices = unique(funnel_historical$brand_country),
            selected = "bbw_ksa",
            multiple = FALSE
          ),


          selectInput(inputId = 'funnel7',
                      label = 'select brand funnel 7 days',
                      choices = unique(funnel7$brand_country),
                      selected = "bbw_ksa",
          ),


          selectInput(inputId = 'funnelt',
                      label = 'select brand funnel today',
                      choices = unique(funnelt$brand_country),
                      selected = "bbw_ksa",
          ),


          plotlyOutput(outputId = "fu1"),
          plotlyOutput(outputId = "fu2"),
          plotlyOutput(outputId = "fu3")


        )),


## 3.7 GA Sessions x Transactions ----------------------------------------------------------
tabItem(tabName = 'ga_data',
        ## contents for the dashboard tab

        fluidPage(
          selectizeInput(
            inputId = "ga_data",
            label = "select brand",
            choices = unique(inner_ga$brand_country),
            selected = "hm_ksa",
            multiple = TRUE
          ),


          plotlyOutput(outputId = "vv2")


        )),


## 6 Outliers CPO Kable ----------------------------------------------------------
tabItem(tabName = 'outliers',
        navbarPage("Outliers",
                   navbarMenu("Last week",
                              tabPanel("Table",
                                       DT::dataTableOutput("outliers"))),
                   navbarMenu("yesterday",
                              tabPanel("Table",
                                       DT::dataTableOutput("outliersy")


                              )))),


## Products GA Sessions ----------------------------------------------------------
tabItem(tabName = 'products_ga',
        ## contents for the dashboard tab



        fluidRow(
          box(title = "Top 50",
              solidHeader = T,
              width = 4,
              collapsible = T,
              collapsed = F,

              plotlyOutput("product"))

        ),


        fluidRow(
          box(title = "Top 50",
              solidHeader = T,
              width = 4,
              collapsible = T,
              collapsed = F,

              plotlyOutput("product60"))

        ),


),


## 3.8 Forecast per Day ----------------------------------------------------------
tabItem(tabName = 'simulator',
        ## contents for the dashboard tab

        fluidPage(
          titlePanel("Totally Cool Useless Stuff
                                                  
                                                  
#            .-.
#           |o,o|"),


          plotlyOutput(outputId = "sim")

        )),


## 3.5 products -----------------------------------------------------
tabItem(tabName = 'products',
        ## 3.3.1 Help text first --------------
        fluidPage(
          selectizeInput(
            inputId = "store_id",
            label = "Select a market",
            choices = unique(df_bbw_products$store_id),
            selected = "15",
            multiple = TRUE
          ),

          plotlyOutput(outputId = "d"),
          plotlyOutput(outputId = "d7")


        ))))


ui <- dashboardPage(title = 'Monster', header, sidebar, body, skin = 'black')

server <- function(input, output, ...) {

  ###
  ### Brand Macro
  ####


  output$m <- renderPlotly({

                             plot_ly(macro, x = ~date, y = ~gross_revenue, name = "gross_revenue") %>%
                               filter(brand %in% input$brand) %>%
                               group_by(brand) %>%
                               add_lines()


                           })

  output$m1 <- renderPlotly({

                              plot_ly(macro, x = ~date, y = ~gross_margin, name = "gross_margin") %>%
                                filter(brand %in% input$brand) %>%
                                group_by(brand) %>%
                                add_lines()


                            })

  output$m2 <- renderPlotly({

                              plot_ly(macro, x = ~date, y = ~gm_per_cent, name = "gm_per_cent") %>%
                                filter(brand %in% input$brand) %>%
                                group_by(brand) %>%
                                add_lines()


                            })


  output$m3 <- renderPlotly({

                              plot_ly(macro, x = ~date, y = ~orders, name = "orders") %>%
                                filter(brand %in% input$brand) %>%
                                group_by(brand) %>%
                                add_lines()


                            })


  output$m4 <- renderPlotly({

                              plot_ly(macro, x = ~date, y = ~session, name = "session") %>%
                                filter(brand %in% input$brand) %>%
                                group_by(brand) %>%
                                add_lines()


                            })


  output$m5 <- renderPlotly({

                              plot_ly(macro, x = ~date, y = ~CvR, name = "CvR") %>%
                                filter(brand %in% input$brand) %>%
                                group_by(brand) %>%
                                add_lines()


                            })


  output$m6 <- renderPlotly({

                              plot_ly(macro, x = ~date, y = ~CiR, name = "CiR") %>%
                                filter(brand %in% input$brand) %>%
                                group_by(brand) %>%
                                add_lines()


                            })


  ###
  ### Brand and Market
  ####

  output$p <- renderPlotly({

                             plot_ly(df_all, x = ~date, y = ~gross_revenue, name = "gross_revenue") %>%
                               filter(brand_country %in% input$brand_country) %>%
                               group_by(brand_country) %>%
                               add_lines()


                           })

  output$p1 <- renderPlotly({

                              plot_ly(df_all, x = ~date, y = ~gross_margin, name = "gross_margin") %>%
                                filter(brand_country %in% input$brand_country) %>%
                                group_by(brand_country) %>%
                                add_lines()


                            })

  output$p2 <- renderPlotly({

                              plot_ly(df_all, x = ~date, y = ~gm_per_cent, name = "gm_per_cent") %>%
                                filter(brand_country %in% input$brand_country) %>%
                                group_by(brand_country) %>%
                                add_lines()


                            })


  output$p3 <- renderPlotly({

                              plot_ly(df_all, x = ~date, y = ~orders, name = "orders") %>%
                                filter(brand_country %in% input$brand_country) %>%
                                group_by(brand_country) %>%
                                add_lines()


                            })


  output$p4 <- renderPlotly({

                              plot_ly(df_all, x = ~date, y = ~session, name = "session") %>%
                                filter(brand_country %in% input$brand_country) %>%
                                group_by(brand_country) %>%
                                add_lines()


                            })


  output$p5 <- renderPlotly({

                              plot_ly(df_all, x = ~date, y = ~CvR, name = "CvR") %>%
                                filter(brand_country %in% input$brand_country) %>%
                                group_by(brand_country) %>%
                                add_lines()


                            })
  ###
  #### Paid Dashboard Render
  ####

  output$paid1 <- renderPlotly({

                                 plot_ly(df_all, x = ~date, y = ~facebook_impressions, name = "facebook impressions") %>%
                                   filter(brand_country %in% input$paid) %>%
                                   group_by(brand_country) %>%
                                   add_lines()


                               })


  output$paid2 <- renderPlotly({

                                 plot_ly(df_all, x = ~date, y = ~facebook_sessions, name = "facebook sessions") %>%
                                   filter(brand_country %in% input$paid) %>%
                                   group_by(brand_country) %>%
                                   add_lines()


                               })


  output$paid3 <- renderPlotly({

                                 plot_ly(df_all, x = ~date, y = ~orders, name = "orders") %>%
                                   filter(brand_country %in% input$paid) %>%
                                   group_by(brand_country) %>%
                                   add_lines()


                               })


  output$paid4 <- renderPlotly({

                                 plot_ly(df_all, x = ~date, y = ~adwords_impressions, name = "adwords impressions") %>%
                                   filter(brand_country %in% input$paid) %>%
                                   group_by(brand_country) %>%
                                   add_lines()


                               })


  output$paid5 <- renderPlotly({

                                 plot_ly(df_all, x = ~date, y = ~criteo_impressions, name = "criteo impressions") %>%
                                   filter(brand_country %in% input$paid) %>%
                                   group_by(brand_country) %>%
                                   add_lines()


                               })


  output$paid6 <- renderPlotly({

                                 plot_ly(df_all, x = ~date, y = ~partnerize_sessions, name = "Partnerize Sessions") %>%
                                   filter(brand_country %in% input$paid) %>%
                                   group_by(brand_country) %>%
                                   add_lines()


                               })


  ####
  #### EDA Render
  ####

  output$eda1 <- renderPlotly({

                                plot_ly(df_all, x = ~date, y = ~prospecting_imp_new, name = "PSP impressions") %>%
                                  filter(brand_country %in% input$eda) %>%
                                  group_by(brand_country) %>%
                                  add_lines()


                              })


  output$eda2 <- renderPlotly({

                                plot_ly(df_all, x = ~date, y = ~remarketing_imp_new, name = "RTG impressions") %>%
                                  filter(brand_country %in% input$eda) %>%
                                  group_by(brand_country) %>%
                                  add_lines()


                              })


  output$eda3 <- renderPlotly({

                                plot_ly(df_all, x = ~date, y = ~prospecting_imp_return, name = "PSP impressions Returning") %>%
                                  filter(brand_country %in% input$eda) %>%
                                  group_by(brand_country) %>%
                                  add_lines()


                              })


  ###
  ### new

  output$pp1 <- renderPlotly({

                               ###
                               ### The default order will be alphabetized unless specified as below:
                               ###


                               fig <- plot_ly(forecast, x = ~ds, y = ~yhat_upper, type = 'scatter', mode = 'lines',
                                              line = list(color = 'transparent'),
                                              showlegend = FALSE, name = 'High Orders')
                               fig <- fig %>%
                                 filter(brand_country %in% input$forecast) %>%
                                 group_by(brand_country) %>%
                                 add_lines()
                               fig <- fig %>% add_trace(y = ~yhat_lower, type = 'scatter', mode = 'lines',
                                                        fill = 'tonexty', fillcolor = 'rgba(0,100,80,0.2)', line = list(color = 'transparent'),
                                                        showlegend = FALSE, name = 'Low Orders')
                               fig <- fig %>% add_trace(x = ~ds, y = ~yhat, type = 'scatter', mode = 'lines',
                                                        line = list(color = 'rgb(0,100,80)'),
                                                        name = 'Modeled Orders')
                               fig <- fig %>% add_trace(x = ~ds, y = ~r_orders, type = 'scatter', mode = 'lines',
                                                        line = list(color = 'rgb(0,0,0)'),
                                                        name = 'Real Orders')
                               fig <- fig %>% layout(title = "Forecast Per Hour",
                                                     paper_bgcolor = 'rgb(255,255,255)', plot_bgcolor = 'rgb(229,229,229)',
                                                     xaxis = list(title = "Months",
                                                                  gridcolor = 'rgb(255,255,255)',
                                                                  showgrid = TRUE,
                                                                  showline = FALSE,
                                                                  showticklabels = TRUE,
                                                                  tickcolor = 'rgb(127,127,127)',
                                                                  ticks = 'outside',
                                                                  zeroline = FALSE,
                                                                  autorange = TRUE),
                                                     yaxis = list(title = "Modeled Orders",
                                                                  gridcolor = 'rgb(255,255,255)',
                                                                  showgrid = TRUE,
                                                                  showline = FALSE,
                                                                  showticklabels = TRUE,
                                                                  tickcolor = 'rgb(127,127,127)',
                                                                  ticks = 'outside',
                                                                  zeroline = FALSE,
                                                                  autorange = TRUE))


                               fig


                             })


  output$vv3 <- renderPlotly({

                               ###
                               ### The default order will be alphabetized unless specified as below:
                               ###


                               fig <- plot_ly(inner_forecast, x = ~ds, y = ~yhat_upper, type = 'scatter', mode = 'lines',
                                              line = list(color = 'transparent'),
                                              showlegend = FALSE, name = 'High Orders')
                               fig <- fig %>%
                                 filter(brand_country %in% input$per_day) %>%
                                 group_by(brand_country) %>%
                                 add_lines()
                               fig <- fig %>% add_trace(y = ~yhat_lower, type = 'scatter', mode = 'lines',
                                                        fill = 'tonexty', fillcolor = 'rgba(0,100,80,0.2)', line = list(color = 'transparent'),
                                                        showlegend = FALSE, name = 'Low Orders')
                               fig <- fig %>% add_trace(x = ~ds, y = ~yhat, type = 'scatter', mode = 'lines',
                                                        line = list(color = 'rgb(0,100,80)'),
                                                        name = 'Modeled Orders')
                               fig <- fig %>% add_trace(x = ~ds, y = ~r_orders, type = 'scatter', mode = 'lines',
                                                        line = list(color = 'rgb(0,0,0)'),
                                                        name = 'Real Orders')
                               fig <- fig %>% layout(title = "Forecast Per Day",
                                                     paper_bgcolor = 'rgb(255,255,255)', plot_bgcolor = 'rgb(229,229,229)',
                                                     xaxis = list(title = "Months",
                                                                  gridcolor = 'rgb(255,255,255)',
                                                                  showgrid = TRUE,
                                                                  showline = FALSE,
                                                                  showticklabels = TRUE,
                                                                  tickcolor = 'rgb(127,127,127)',
                                                                  ticks = 'outside',
                                                                  zeroline = FALSE,
                                                                  autorange = TRUE),
                                                     yaxis = list(title = "Modeled Orders",
                                                                  gridcolor = 'rgb(255,255,255)',
                                                                  showgrid = TRUE,
                                                                  showline = FALSE,
                                                                  showticklabels = TRUE,
                                                                  tickcolor = 'rgb(127,127,127)',
                                                                  ticks = 'outside',
                                                                  zeroline = FALSE,
                                                                  autorange = TRUE,
                                                                  fixedrange = FALSE))


                               fig


                             })


  #####
  #### GA_sessions
  ####

  output$vv2 <- renderPlotly({

                               ###
                               ### The default order will be alphabetized unless specified as below:
                               ###


                               fig <- plot_ly(inner_ga, x = ~date, y = ~sessions, mode = 'lines', name = "sessions")
                               fig <- fig %>%
                                 filter(brand_country %in% input$ga_data) %>%
                                 group_by(brand_country) %>%
                                 add_lines()
                               fig <- fig %>% add_trace(y = ~transactions, type = 'scatter', mode = 'lines', name = "transactions", yaxis = "y2")
                               fig <- fig %>% layout(yaxis2 = list(overlaying = "y", side = "right"))


                               fig


                             })


  #####
  #### Funnel
  ####

  output$fu1 <- renderPlotly({


                               fig <- plot_ly(funnel_historical)
                               fig <- fig %>%
                                 filter(brand_country %in% input$funnel_historical) %>%
                                 group_by(brand_country) %>%
                                 add_trace(type = "funnel",
                                           y = ~shoppingStage,
                                           x = ~users,
                                           textposition = "inside",
                                           textinfo = "value+percent initial",
                                           opacity = 0.65,
                                           marker = list(color = c("deepskyblue", "darkblue", "tan", "teal", "silver", "darkgrey", "green"),
                                                         line = list(width = c(4, 2, 2, 3, 1, 1), color = c("wheat", "wheat", "blue", "wheat", "wheat"))),
                                           connector = list(line = list(color = "royalblue", dash = "dot", width = 3)))
                               fig <- fig %>%
                                 layout(title = "Historical trend", yaxis = list(categoryarray = c("ALL_VISITS", "PRODUCT_VIEW", "CHECKOUT_1",
                                                                                                   "CHECKOUT_2", "CHECKOUT_3", "TRANSACTION")))


                               fig

                             })


  #####
  #### Funnel
  ####

  output$fu2 <- renderPlotly({


                               fig <- plot_ly(funnel7)
                               fig <- fig %>%
                                 filter(brand_country %in% input$funnel7) %>%
                                 group_by(brand_country) %>%
                                 add_trace(type = "funnel",
                                           y = ~shoppingStage,
                                           x = ~users,
                                           textposition = "inside",
                                           textinfo = "value+percent initial",
                                           opacity = 0.65,
                                           marker = list(color = c("deepskyblue", "darkblue", "tan", "teal", "silver", "darkgrey", "green"),
                                                         line = list(width = c(4, 2, 2, 3, 1, 1), color = c("wheat", "wheat", "blue", "wheat", "wheat"))),
                                           connector = list(line = list(color = "royalblue", dash = "dot", width = 3)))
                               fig <- fig %>%
                                 layout(title = " 7 days Trend", yaxis = list(categoryarray = c("ALL_VISITS", "PRODUCT_VIEW", "CHECKOUT_1",
                                                                                                "CHECKOUT_2", "CHECKOUT_3", "TRANSACTION")))


                               fig


                             })


  output$fu3 <- renderPlotly({


                               fig <- plot_ly(funnelt)
                               fig <- fig %>%
                                 filter(brand_country %in% input$funnelt) %>%
                                 group_by(brand_country) %>%
                                 add_trace(type = "funnel",
                                           y = ~shoppingStage,
                                           x = ~users,
                                           textposition = "inside",
                                           textinfo = "value+percent initial",
                                           opacity = 0.65,
                                           marker = list(color = c("deepskyblue", "darkblue", "tan", "teal", "silver", "darkgrey", "green"),
                                                         line = list(width = c(4, 2, 2, 3, 1, 1), color = c("wheat", "wheat", "blue", "wheat", "wheat"))),
                                           connector = list(line = list(color = "royalblue", dash = "dot", width = 3)))
                               fig <- fig %>%
                                 layout(title = "Yesterday Trend", yaxis = list(categoryarray = c("ALL_VISITS", "PRODUCT_VIEW", "CHECKOUT_1",
                                                                                                  "CHECKOUT_2", "CHECKOUT_3", "TRANSACTION")))


                               fig


                             })


  ###
  #### Product render
  ###

  output$d <- renderPlotly({

                             plot_ly(df_bbw_products, x = ~name, y = ~total, type = 'scatter', mode = 'markers',
                                     size = ~total, color = ~total, colors = 'Reds',
                                     sizes = c(10, 50),
                                     marker = list(opacity = 0.5, sizemode = 'diameter')) %>% layout(title = 'last 7 Days Top Sellers BBW',
                                                                                                     xaxis = list(showgrid = FALSE),
                                                                                                     yaxis = list(showgrid = FALSE),
                                                                                                     showlegend = FALSE)

                           })


  output$d7 <- renderPlotly({

                              plot_ly(df_bbw_products_14, x = ~name, y = ~total, type = 'scatter', mode = 'markers',
                                      size = ~total, color = ~total, colors = 'Reds',
                                      sizes = c(10, 50),
                                      marker = list(opacity = 0.5, sizemode = 'diameter')) %>% layout(title = '7-14 Days Top Sellers BBW',
                                                                                                      xaxis = list(showgrid = FALSE),
                                                                                                      yaxis = list(showgrid = FALSE),
                                                                                                      showlegend = FALSE)

                            })


  #####
  #### Product GA BBW KSA
  ###


  output$product <- renderPlotly({


                                   fig <- plot_ly(bbw_ksa_product)
                                   fig <- fig %>% add_trace(x = ~productName, y = ~itemRevenue, type = 'bar',
                                                            textposition = 'auto', name = "revenue",
                                                            marker = list(color = 'rgb(158,202,225)',
                                                                          line = list(color = 'rgb(8,48,107)', width = 1.5)))
                                   fig <- fig %>% add_trace(x = ~productName, y = ~productListClicks, type = 'bar',
                                                            textposition = 'auto', name = "clicks",
                                                            marker = list(color = 'rgb(58,200,225)',
                                                                          line = list(color = 'rgb(8,48,107)', width = 1.5)))
                                   fig <- fig %>% layout(title = "BBW KSA SAS",
                                                         barmode = 'group',
                                                         xaxis = list(title = ""),
                                                         yaxis = list(title = ""))

                                   fig

                                 })


  #####
  #### Product GA BBW KSA
  ###


  output$product60 <- renderPlotly({


                                     fig <- plot_ly(bbw_ksa_product_60)
                                     fig <- fig %>% add_trace(x = ~productName, y = ~itemRevenue, type = 'bar',
                                                              textposition = 'auto', name = "revenue",
                                                              marker = list(color = 'rgb(158,202,225)',
                                                                            line = list(color = 'rgb(8,48,107)', width = 1.5)))
                                     fig <- fig %>% add_trace(x = ~productName, y = ~productListClicks, type = 'bar',
                                                              textposition = 'auto', name = "clicks",
                                                              marker = list(color = 'rgb(58,200,225)',
                                                                            line = list(color = 'rgb(8,48,107)', width = 1.5)))
                                     fig <- fig %>% layout(title = "BBW KSA Prior SAS",
                                                           barmode = 'group',
                                                           xaxis = list(title = ""),
                                                           yaxis = list(title = ""))

                                     fig

                                   })


  #####
  #### outliers table
  ###


  output$outliers <- DT::renderDataTable({
                                           DT::datatable(df_cpo) %>%
                                             formatPercentage('CIR',
                                                              2) %>%
                                             formatPercentage('CvR',
                                                              2) %>%
                                             formatPercentage('new_customers', 2) %>%
                                             formatPercentage('target_cir', 0) %>%
                                             formatRound("CPV",
                                                         digits = 2) %>%
                                             formatRound("sessions", digits = 0,
                                                         interval = 3) %>%
                                             formatCurrency(c(
                                               'CPO', 'CPA', 'AOV')) %>%
                                             formatRound("orders",
                                                         digits = 0,
                                                         interval = 3,
                                                         mark = ",") %>%
                                             formatCurrency('total_cost', digits = 0) %>%
                                             formatCurrency('gross_revenue', digits = 0)


                                         })


  #####
  #### outliers table
  ###


  output$outliersy <- DT::renderDataTable({
                                            DT::datatable(df_cpo_yesterday) %>%
                                              formatPercentage('CIR',
                                                               2) %>%
                                              formatPercentage('CvR',
                                                               2) %>%
                                              formatPercentage('new_customers', 2) %>%
                                              formatPercentage('target_cir', 0) %>%
                                              formatRound("CPV",
                                                          digits = 2) %>%
                                              formatRound("sessions", digits = 0,
                                                          interval = 3) %>%
                                              formatCurrency(c(
                                                'CPO', 'CPA', 'AOV')) %>%
                                              formatRound("orders",
                                                          digits = 0,
                                                          interval = 3,
                                                          mark = ",") %>%
                                              formatCurrency('total_cost', digits = 0) %>%
                                              formatCurrency('gross_revenue', digits = 0)


                                          })


  ####
  ### Simulator Zone
  ####


  output$sim <- renderPlotly({

                               df1 <- df1
                               fig <- df1 %>%
                                 plot_ly(
                                   x = ~total_cost,
                                   y = ~session,
                                   size = ~total_cost,
                                   color = ~brand,
                                   frame = ~month_id,
                                   text = ~year_id,
                                   hoverinfo = "text",
                                   type = 'scatter',
                                   mode = 'markers'
                                 )
                               fig <- fig %>% layout(
                                 paper_bgcolor = 'rgb(255,255,255)',
                                 xaxis = list(
                                   type = "log"
                                 )
                               )

                               fig

                             })


}


options(shiny.host = '0.0.0.0')
options(shiny.port = 8888)
shinyApp(ui, server)
