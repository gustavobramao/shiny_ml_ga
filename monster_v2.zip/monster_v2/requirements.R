packages <- c("DT","dygraphs","tidyverse","config","shinydashboard","dplyr",
              "bigrquery","googleAuthR","readr","gridExtra","shinyWidgets",
              "shinycssloaders","h2o","scales","gsheet","knitr","vip","prophet",
              "tidyr","rgl","shinyML","highcharter","shiny","plotly","lubridate",
              "gtrendsR","bigQueryR","TSstudio")


if (length(setdiff(packages, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(packages, rownames(installed.packages())))
}

install.packages("XML", repos = "http://www.omegahat.net/R")
