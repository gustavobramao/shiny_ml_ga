library(shinyML)
library(rgl)
library(h2o)
library(DT)
library(shinyWidgets)
library(shiny)
library(shinydashboard)
library(dygraphs)
library(shinycssloaders)
library(plotly)
library(prophet)
library(googleAuthR)
library(gsheet)
library(tidyr)

if (config::is_active("production")) {
    print("Environment is production")
    setwd('/var/www/shiny_app')
}

if (config::is_active("default")) {
    print("Environment is default")
}

source("ml_helpers.R")

####
### Test ML Model UI
###


### call first function to get data refreshed before computing h20.ai
get_ml_models_data()



h2o.init()
h2o_shiny(y = "transactions", date_column = "date", share_app = TRUE, port = 5006)
