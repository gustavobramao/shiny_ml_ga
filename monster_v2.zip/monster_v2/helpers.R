library(bigrquery)

get_bq_conn <- function () {
  # BigQuery Auth
  bq_auth(path = "conn.json")
  projectid <- 'uts-mdsi'
  datasetid <- 'stds_assignment'
  bq_conn <- dbConnect(
    bigquery(),
    project = "authentic-codex-225113",
    dataset = "monaliza_bi",
    use_legacy_sql = FALSE
  )
  return(bq_conn)
}


get_subset_df <- function(data, columns){
  data <- data[,!(names(data) %in% columns)]
  return(data)
}

set_config_variables <- function(){
  if (config::is_active("production")) {
    print("Environment is production")
    setwd('/var/www/shiny_app')
  }

  if (config::is_active("default")) {
      print("Environment is default")
  }
}